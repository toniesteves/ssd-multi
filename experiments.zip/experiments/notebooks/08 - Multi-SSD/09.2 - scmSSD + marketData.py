
import os
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt

import matplotlib.dates as mdates
from matplotlib.ticker import MultipleLocator

import cplex
from docplex.mp.model import Model
from cplex.callbacks import UserCutCallback, LazyConstraintCallback, SolveCallback
from docplex.mp.callbacks.cb_mixin import ConstraintCallbackMixin

np.set_printoptions(precision=8, suppress=True)

pd.set_option('display.max_columns', 1000)
pd.set_option('expand_frame_repr', False)


def sort_benchmark(benchmark: pd.DataFrame) -> list[np.ndarray]:
    """
    Ordena um benchmark (DataFrame com uma ou mais colunas)
    em ordem crescente.

    Args:
        benchmark: DataFrame contendo uma ou mais colunas.

    Returns:
        Lista de np.ndarray contendo os valores ordenados por coluna.
    """
    return [np.sort(benchmark[col].values) for col in benchmark.columns]


def missing_percentage(df, threshold=0):
    """
    Retorna a quantidade e porcentagem de valores ausentes por coluna,
    filtrando colunas com porcentagem maior que o threshold.

    Se nenhuma coluna tiver valores ausentes, retorna uma mensagem.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame analisado.

    threshold : float
        Percentual mínimo de dados ausentes para exibir a coluna.
        Exemplo: threshold=10 mostra apenas colunas com mais de 10% de NaN.
    """

    missing_pct = df.isnull().mean() * 100

    result = pd.DataFrame({
        'missing_count': df.isnull().sum(),
        'missing_percentage': missing_pct
    })

    # mantém apenas colunas com pelo menos 1 NaN
    result = result[result['missing_count'] > 0]

    # verifica se existe alguma coluna com NaN
    if result.empty:
        return "Nenhuma coluna possui dados faltantes."

    # aplica threshold
    result = result[result['missing_percentage'] > threshold]

    return result.sort_values(by='missing_percentage', ascending=False)


def remove_empty_samples(df, threshold):
    """
    Remove colunas onde a porcentagem de valores ausentes (NaN) 
    é maior que o threshold fornecido.
    
    Parâmetros:
    df (pd.DataFrame): O dataframe original.
    threshold (float): Valor entre 0 e 1 (ex: 0.30 para remover colunas com >30% de NaN).
    """
    # Calcula a média de valores nulos por coluna
    # Como True=1 e False=0, a média representa a porcentagem de nulos
    colunas_para_manter = df.columns[df.isnull().mean() <= threshold]
    
    return df[colunas_para_manter]


def fill_missing_data(df):
    """
    Preenche dados ausentes usando ffill seguido de bfill.
    
    O ffill preenche os nulos com o valor anterior.
    O bfill preenche os nulos restantes com o próximo valor.
    """
    return df.ffill().bfill()


def plot_portfolio_comparison(portfolio, force_background=False):
    """
    Plota o comparativo de performance entre o portfólio (estratégia)
    e o benchmark S&P 500, ambos normalizados.
    """
    plt.figure(figsize=(20, 10))

    ax = plt.gca()

    if force_background:
        ax.set_facecolor("white")
        ax.figure.set_facecolor("white")

    # CORREÇÃO AQUI: Convertendo o índice para Datetime para a linha não sumir/cortar
    index_dt = pd.to_datetime(portfolio.index)

    # Plotagem usando o índice convertido em Datetime nativo
    plt.plot(index_dt, portfolio["SSD"], label="SSD Toni")
    plt.plot(index_dt, portfolio["SP500"], label="SP500")

    if "Risk free rate" in portfolio.columns:
        plt.plot(index_dt, portfolio["Risk free rate"], label="Risk free rate", linestyle="--")

    # ============================================================
    # CONFIGURAÇÃO DO EIXO X (Dias 01 e 15 sem quebrar as linhas)
    # ============================================================
    # Localiza matematicamente os dias 1 e 15 de cada mês ao longo da linha do tempo
    ax.xaxis.set_major_locator(mdates.MonthLocator(bymonthday=[1, 15]))

    # Formata a exibição exatamente como você quer: Ano-Mês-Dia
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    # ============================================================

    plt.title("Comparativo de Performance dos Portfólios", fontsize=20)
    plt.xlabel("Data", fontsize=16)
    plt.ylabel("Valor normalizado", fontsize=16)

    plt.legend(fontsize=14)
    plt.grid(True, alpha=0.3)   # O grid segue os dias 1 e 15 automaticamente
    plt.xticks(rotation=45)

    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.tick_params(axis='both', colors='gray', labelsize=14)

    plt.tight_layout()
    plt.show()


in_sample_days      = 200
oos_start           = '2024-01-01'
oos_end             = '2024-06-01'


factorsReturns   = pd.read_csv("../../data/factors.csv")

marketData   = pd.read_csv("../../data/marketData.csv", parse_dates=["Date"])
marketData.set_index("Date", inplace=True)


missing_percentage(marketData)


cleanMarketData = remove_empty_samples(marketData, 0.15) # Remove amostras com mais de 15% ausentes
cleanMarketData = fill_missing_data(cleanMarketData)      # Aplica ffil bfill

print(cleanMarketData.shape)
missing_percentage(cleanMarketData)


marketDataPrices    = cleanMarketData.copy().abs()


benchmarks = ['SP500']

oosMarketDataPrices = marketDataPrices.loc[oos_start:oos_end]
oosBenchmarkPrices  = oosMarketDataPrices[benchmarks]
oosMarketDataPrices = oosMarketDataPrices.drop(columns=benchmarks)
print(oosBenchmarkPrices.shape, oosMarketDataPrices.shape)


marketDatareturns = marketDataPrices.diff() / marketDataPrices.shift(1)
marketDatareturns[factorsReturns.columns] = factorsReturns.to_numpy()
marketDatareturns = marketDatareturns[1:]
marketDatareturns.head()



benchmarks = benchmarks + factorsReturns.columns.to_list()

# ['SP500', 'CMA', 'HML', 'MARKET', 'RMW', 'SMB']

insampleBenchmarkReturns  = marketDatareturns[benchmarks]
insampleMarketDataReturns = marketDatareturns.drop(columns=benchmarks)
print(insampleBenchmarkReturns.shape, insampleMarketDataReturns.shape)

# benchmarks = [benchmarks[5]]
insampleBenchmarkReturns = insampleBenchmarkReturns[benchmarks]

insampleMarketDataReturns.shape, insampleBenchmarkReturns.shape, oosMarketDataPrices.shape

n_cols = 600
insampleMarketDataReturnsCopy = insampleMarketDataReturns.iloc[:, :n_cols]
oosMarketDataPricesCopy       = oosMarketDataPrices.iloc[:, :n_cols]



class SSDLazyCallback(ConstraintCallbackMixin, LazyConstraintCallback, SolveCallback):

    def __init__(self, env):
        LazyConstraintCallback.__init__(self, env)
        ConstraintCallbackMixin.__init__(self)
        self.n_calls    = 0
        self.tolerance  = 1e-6
        self.debug      = False
        self.cuts_debug = False

    def __call__(self):

        if self.get_cplex_status() == self.status.optimal:
            self.n_calls += 1

            if self.cuts_debug: print('-' * 40)
            if self.cuts_debug: print(f"\n [INFO]: Running separation algorithm #{self.n_calls} ")

            n_scenarios   = len(self.scenarios)
            n_assets      = self.scenarios.shape[1]
            curr_solution = self.make_complete_solution()
            curr_w_values = {var.name: self.get_values(var.index) for var in self.w_vars}
            V_value       = curr_solution[self.model.get_var_by_name('V')]
            w_values      = [self.get_values(w.index) for w in self.w_vars]

            if self.logging_mode > 3:
                print(f"\n{'V':<5}: {V_value:.5f}")
                print(f"Weights:")
                my_array = np.array([w for w in w_values])
                print(f"\n{my_array}")

            # Calculando Tail(R'w) para todo t.
            portfolio_returns = self.scenarios @ w_values

            # Ordenar pelo valor do retorno e Imprimir formatado
            idx_returns = list(enumerate(portfolio_returns))
            sorted_idx_returns  = sorted(idx_returns, key=lambda x: x[1])
            if self.logging_mode > 3:
                for rank, (original_index, value) in enumerate(sorted_idx_returns, start=1):
                    print(f"\t{rank:2}-th worst return: {value: .5f} (index {original_index})")
                print()

            # Ordena os retornos do portfólio
            sorted_p_returns = sorted(portfolio_returns)
            cum_p_returns = np.cumsum(sorted_p_returns)

            n_benchmarks = len(self.benchmarks)

            for k in range(n_benchmarks):
                sorted_b_returns = self.benchmarks[k]
                cum_b_returns = np.cumsum(sorted_b_returns)

                # Pega os valores atuais de Vs para o benchmark k
                Vs_vars_k = self.Vs_all[k]
                Vs_values_k = [self.get_values(var.index) for var in Vs_vars_k]

                max_diff  = -np.inf
                max_index = None
                max_ret   = None

                for s, ret in enumerate(cum_p_returns):

                    tau_s    = cum_b_returns[s]
                    lhs_expr = Vs_values_k[s]
                    rhs_expr = ret - tau_s

                    diff     = lhs_expr - rhs_expr
                    
                    if self.logging_mode > 3: print(f"\t[Bench {k}] |Js| = {s + 1:2d}, C: {lhs_expr:.5f} - ({ret:.5f}) <= ({tau_s:.5f}) (Violated by {diff:.5f})")

                    if lhs_expr > rhs_expr + self.tolerance:

                        if diff > max_diff:
                            max_diff  = diff
                            max_index = s
                            max_ret   = ret

                if max_index is not None:

                    if self.logging_mode > 3:
                        print(f"\n[INFO]: SSD constraint violated to Vs_{k}_{max_index}\n")
                        print(f"[INFO]: Violation: {max_diff}\n")

                    Vs = self.model.get_var_by_name(f"Vs_{k}_{max_index}")

                    # Obtém os índices dos |J| piores cenários
                    worst_scenario_indices = [idx for idx, _ in sorted_idx_returns[:max_index + 1]]  # max_index é zero-based
                    if self.debug: print(f"\tWorst Scenario Indices: {worst_scenario_indices}")

                    # Soma os retornos desses cenários
                    cumulative_scenario = np.sum(self.scenarios[worst_scenario_indices, :], axis=0)

                    # Construção explícita do corte
                    scenario_return = self.model.sum(cumulative_scenario[i] * self.w_vars[i] for i in range(n_assets))
                    rhs             = cum_b_returns[max_index]

                    if self.logging_mode > 3:
                        formatted_values = [f"{ret:.5f}" for ret in cumulative_scenario]
                        if self.debug: print(f"\tWorst Scenario Returns: {formatted_values}")

                    if self.logging_mode > 3:
                        print(f"\t{'Cut to be added':<22}: ", end="")
                        for i in range(n_assets):
                            print(f"{cumulative_scenario[i]:.5f} {self.w_vars[i].name} + ", end="")
                        print(f"1 {Vs} <= {rhs:.5f}\n")

                    # Adiciona restrição
                    cpx_lhs, sense, cpx_rhs = self.linear_ct_to_cplex((Vs) <= scenario_return - rhs)


                    self.add(cpx_lhs, sense, cpx_rhs)

                    if self.logging_mode > 3:
                        print(f"\t\033[92m> Violated constraint added.\033[0m\n")

            if self.logging_mode > 3:
                print(f"\t> End of Separation Algorithm.")
                print('-' * 40)


def solve_ssd(scenarios, benchmarks, scaled, logging_mode=0, callback=False, verbose=False):

    print("\n=== STARTING SSD MODEL ===")
    model         = Model(name='SSD')
    n_scenar      = scenarios.shape[0]
    n_assets      = scenarios.shape[1]
    model_verbose = False
    MODEL_NAME    = "scmSSD"
    scenarios     = np.array(scenarios)

    if isinstance(benchmarks, np.ndarray) and benchmarks.ndim == 1:
        benchmarks = [benchmarks]
    elif not isinstance(benchmarks, list):
        benchmarks = [np.array(benchmarks)]

    n_benchmarks = len(benchmarks)

    # Variáveis
    model.parameters.preprocessing.presolve         = 0
    model.parameters.mip.display                    = 4
    model.parameters.threads                        = 1
    model.parameters.emphasis.numerical             = 1
    model.parameters.randomseed                     = 0
    model.parameters.emphasis.mip                   = 2
    model.parameters.simplex.tolerances.optimality  = 1e-9
    model.parameters.simplex.tolerances.feasibility = 1e-9
    model.parameters.timelimit                      = 900
    model.parameters.mip.tolerances.absmipgap       = 0
    model.parameters.mip.tolerances.mipgap          = 0
    model.parameters.mip.tolerances.integrality     = 0

    # Variáveis
    w  = model.continuous_var_list(n_assets, lb=0, ub=1, name='wl')
    
    Vs_all = {}
    for k in range(n_benchmarks):
        Vs_all[k] = model.continuous_var_list(n_scenar, name=f'Vs_{k}', lb=-model.infinity, ub=model.infinity)
        
    V  = model.continuous_var(name="V", lb=-model.infinity, ub=model.infinity)
    cb = model.binary_var(name='cb_temp')

    # Restrições básicas
    model.add_constraint(model.sum(w) == 1, ctname="budget")

    for k in range(n_benchmarks):
        benchmark_ordenado = np.sort(benchmarks[k])
        cum_b_returns      = np.cumsum(benchmark_ordenado)

        for t in range(n_scenar):
            model.add_constraint((t + 1) * V <= Vs_all[k][t], ctname=f"maxmin_{k}_{t}")
            
            soma_cenarios_t = np.sum(scenarios[:t+1, :], axis=0)
            scenario_return = model.sum(soma_cenarios_t[i] * w[i] for i in range(n_assets))
            tau_s           = cum_b_returns[t]        
            model.add_constraint(Vs_all[k][t] <= scenario_return - tau_s, ctname=f"ssd_{k}_{t}")

    
    model.maximize(V + 0.0 * cb)


    if logging_mode == 3:
        for ct in model.iter_constraints():
            print(f"Name: {ct.name}, Expression: {ct.left_expr} {ct.sense} {ct.right_expr}")


    model.export_as_lp(f"../../models/{MODEL_NAME}.lp")

    if logging_mode == 2:
        print(model.print_information())

    if callback:
        # Registra o callback e passa os parâmetros necessários
        lazy_cb = model.register_callback(SSDLazyCallback)
        lazy_cb.scenarios      = scenarios
        lazy_cb.benchmarks     = benchmarks
        lazy_cb.scaled         = scaled
        lazy_cb.w_vars         = w
        lazy_cb.Vs_all         = Vs_all
        lazy_cb.logging_mode   = logging_mode

        model.lazy_callback = lazy_cb

    print("\nIniciando processo de otimização...")
    if logging_mode > 0: model_verbose = True
    sol = model.solve(log_output=model_verbose)

    if sol:
        optimized_weights = [sol[wi] for wi in w]
        weights           = np.array(optimized_weights)
        print("\n[INFO]: Solução encontrada:")
        print(f"\tV              {sol[V]}")
        print(f"\tBest Solution = {sol.get_objective_value()}")
        print(f"\tNº of Cuts    = {model.get_cuts()['user']}")
        print()

        return sol[V], sol.get_objective_value(), weights
    else:
        raise RuntimeError("No solution found for the optimization problem!")


def WFV(prices, returns, benchmark, scaled, logging_mode=0, sliding=True):

    INITIAL_CAPITAL       = 1000000

    portfolio_shares_held = pd.DataFrame()
    weights_invested      = pd.DataFrame()
    rebalances_df         = pd.DataFrame()
    optInfoData           = pd.DataFrame()
    valuation_df          = pd.DataFrame()
    shares_df             = pd.DataFrame()
    norm_portfolio_df     = pd.DataFrame(columns=["SSD"])

    print('---------------------------------------------------------------')
    print('[INFO]: Simulation Started...\n')

    initial_train_days = 200
    validation_days    = 1
    rebalance_freq     = 21

    data_length = len(returns)
    # max_steps   = data_length - initial_train_days + 1
    max_steps = len(prices)

    last_share = None


    for step in range(0, max_steps, validation_days):

        train_start = step if sliding else 0
        train_end   = train_start + initial_train_days

        train           = returns.iloc[train_start:train_end]
        train_bench     = benchmark.iloc[train_start:train_end]
        valid           = returns.iloc[train_end-1:train_end]

        train_bench_sorted     = sort_benchmark(train_bench)

        if logging_mode == 4:
            print(f"\nRef:")
            print(np.array(train_bench).flatten())

            for i, col in enumerate(train.columns):
                print(f"\nAsset: {i} - {col}")
                valores_array = train[col].to_numpy()
                print(f"\n{valores_array}")

            print("------------- END INSTANCE - --------------")

            print("All references:")
            print(f"\nRef:")
            print(np.array(train_bench).flatten())

            print(f"\nSorted Ref:")
            print(np.array(train_bench_sorted))


        v_value, func_obj, weights_arr = solve_ssd(train, train_bench_sorted, scaled, logging_mode= logging_mode, callback=True, verbose=False)

        v_df        = pd.DataFrame([v_value], columns=['obj'], index=valid.index)
        weights_opt = pd.DataFrame([weights_arr], columns=valid.columns, index=valid.index)

        print(f"Day: {step + 1} ({valid.index.min()})")
        print(f"\tSum proportions: {np.sum(weights_arr)*100}%")
        print(f"\tFUNÇÃO OBJETIVO: {func_obj}")

        # ============================================================
        # SIMULATION
        # ============================================================

        price = np.array(prices.loc[prices.index[step], :])

        # ============================================================
        # DIA 0 — primeiro dia da simulação
        # ============================================================
        if step == 0:
            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            valuation     = (weights_arr * INITIAL_CAPITAL)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

            optInfoData   = pd.concat([optInfoData, v_df])

            train.to_csv(f"rebalanceInsampleWeights-{valid.index.min().strftime('%Y-%m-%d')}.csv", index=False)

        # ============================================================
        # DIA DE REBALANCEAMENTO
        # ============================================================
        elif step % rebalance_freq == 0:

            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            data_str = valid.index.min().strftime('%Y-%m-%d')
            train.to_csv(f"rebalanceInsampleWeights-{data_str}.csv", index=False)
            optInfoData = pd.concat([optInfoData, v_df])
            
            valuation_normal = (last_share * price)
            total_value      = np.sum(valuation_normal)

            print(f"\tValuation before rebalance: {total_value}")

            valuation     = (weights_arr * total_value)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

        # ============================================================
        # DIA SEM REBALANCEAMENTO
        # ============================================================
        else:
            share     = last_share
            valuation = share * price

        # ============================================================
        # Armazenamento
        # ============================================================
        # break

        date_idx = valid.index[0]

        valuation_df     = pd.concat([valuation_df,pd.DataFrame([valuation], index=[date_idx], columns=valid.columns)])

        shares_df        = pd.concat([shares_df, pd.DataFrame([share], index=[date_idx], columns=valid.columns)])
        weights_invested = pd.concat([weights_invested, weights_opt])

        norm_portfolio_df.loc[date_idx, "SSD"] = (np.sum(valuation) / INITIAL_CAPITAL)

        last_share = share

        print(f"\tPortfolio Value: {np.sum(valuation)}")
        print(f"\tNorm Portfolio: {np.sum(valuation)/INITIAL_CAPITAL}")
        print('---------------------------------------------------------------\n')
        
    return (norm_portfolio_df, weights_invested, rebalances_df, valuation_df, shares_df, optInfoData)



if __name__ == "__main__":
    
    os.system('cls' if os.name == 'nt' else 'clear')


    portfolio, weightsInvested, weightsRebalance, portfolioValuation, portfolioShares, optmizationInfoData = WFV(oosMarketDataPricesCopy,
                                                                                                                 insampleMarketDataReturnsCopy,
                                                                                                                 insampleBenchmarkReturns,
                                                                                                                 scaled       = 0,
                                                                                                                 logging_mode = 1, 
                                                                                                                 sliding      = True)

    # print(portfolio.shape)
    # print(portfolio)

    # print(weightsRebalance.shape)
    # print(weightsRebalance)

    # print(portfolioValuation.shape)
    # print(portfolioValuation)

    # print(weightsInvested.shape)
    # print(weightsInvested)

    # print(portfolioShares.shape)
    # print(portfolioShares)

    print(optmizationInfoData)

    sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
    sp500_prices.set_index('date', inplace=True)
    sp500_slice = sp500_prices.loc['2023-10-31':'2023-11-30', 'SP500'].abs()
    sp500_slice

    sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
    sp500_prices.set_index('date', inplace=True)
    sp500_slice = sp500_prices.loc[oos_start:oos_end, 'SP500'].abs()
    sp500 = sp500_slice / sp500_slice.iloc[0]
    portfolio['SP500'] = sp500
    portfolio['Risk free rate'] = 1.0
    portfolio

    plot_portfolio_comparison(portfolio, force_background=True)

    print('\n==========================================================')
    print('Finalising simulation...')