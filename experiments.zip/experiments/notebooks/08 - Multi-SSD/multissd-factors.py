# %% [markdown]
# ### Multi-SSD
# 
# The SSD formulation can be easily extended to include dominance of multiple reference distributions. 
# In summary, we are looking for a single portfolio that dominates multiple benchmarks with respect to SSD. 
# Instead of a single set containing $S$ scenarios, let there be $K$ non-empty scenario sets 
# $\{1,\ldots,S^k\}$, $k = 1,\ldots,K$, with $S^k$ scenarios each. 
# For each set let there be a corresponding reference distribution $I^k$ with $S^k$ discrete returns.
# 
# For each asset $i = 1,\ldots,N$, let $r^{k}_{is}$ be the return on scenario $s = 1,\ldots,S^k$. 
# Let $\hat{\tau}^k_s = \mathrm{Tail}^L_{\frac{s}{S^k}}(I^k)$ for $s = 1,\ldots,S^k$, $k = 1,\ldots,K$. Then let:
# \begin{equation}
# \mathcal{V}^k_s = \mathrm{Tail}^L_{s/S^k}(P) - \hat{\tau}^k_s, 
# \quad s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{equation}
# 
# Let $\mu^k_s > 0$ be the weight that we attach to $\mathcal{V}^k_s$. Then a suitable optimisation program 
# for solving the Multi-SSD problem is:
# 
# \begin{equation}
# \max \ \mathcal{V}
# \end{equation}
# 
# subject to:
# \begin{align}
# \mathcal{V} &\leq \mathcal{V}^k_s, && s = 1,\ldots,S^k,\; k = 1,\ldots,K, \\
# \mathcal{V}^k_s &\leq \frac{1}{S^k} \sum_{j \in \mathcal{J}} \sum_{i=1}^N r_{ij} w_i - \hat{\tau}^k_s, 
# && \mathcal{J} \subseteq \{1,\ldots,S^k\},\; |\mathcal{J}| = s, \\
# \sum_{i=1}^N w_i &= 1, \\
# \mathcal{V}^k_s &\in \mathbb{R}, && s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{align}
# 
# For the scaled version of the Multi-SSD formulation we replace the first constraints with:
# \begin{equation}
# \frac{s}{S^k} \mathcal{V} \leq \mathcal{V}^k_s, 
# \quad s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{equation}

# %% [markdown]
# ### Experiments
# 
# 
# Basic experiment:
#  - Scaled SSD model
#  - 200 days in-sample
#  - Data for S&P500 companies
#  - Rebalancing every 21 days
#  - Out-of-sample period from 01/01/2024 to 01/06/2024
#  - No transaction costs, or lot sizes
# 
# Benchmarks: S&P500 index and HML, SMB and CMA factor returns.
# 
#  - CMA: Conservative minus Aggressive
#  - HML: High minus Low
#  - SMB: Small minus Big
# 4 rebalances

# %% [markdown]
# ### Imports

# %%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import cplex
from docplex.mp.model import Model
from cplex.callbacks import UserCutCallback, LazyConstraintCallback, SolveCallback
from docplex.mp.callbacks.cb_mixin import ConstraintCallbackMixin

pd.set_option('display.max_columns', 1000)
pd.set_option('expand_frame_repr', False)

# %% [markdown]
# ### Data

# %%
factors = pd.read_csv('../../data/extracted_factors_data.csv', parse_dates=['date'])
factors.set_index('date', inplace=True)

print(f"Min. Date: {factors.index.min()}")
print(f"Max. Date: {factors.index.max()}")
print(f"Nº Rows: {factors.shape[0]}")
print(f"Nº Cols: {factors.shape[1]}\n")

factors.info()

# %%
factors.head()

# %%
sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
sp500_prices.set_index('date', inplace=True)

print(f"Min. Date: {sp500_prices.index.min()}")
print(f"Max. Date: {sp500_prices.index.max()}")
print(f"Nº Rows:   {sp500_prices.shape[0]}")
print(f"Nº Cols:   {sp500_prices.shape[1]}\n")

sp500_prices.info()

# %%
sp500_returns = sp500_prices.diff()[1:] / sp500_prices.shift(1)[1:]
sp500_returns.head()

# %%
# Load Real Market Data
selected_assets_idx = ['0157B1', '03B8CF', '055018', '061366', '0624BE', '063384', '067779', '06EF42', '07EC43', '095294']
selected_assets     = ['AMZN','MMM','COF','FSLR','ANF','BG','CCL','DHI','CTSH','DXC']

assets = pd.read_csv('../../data/extracted_assets_data.csv', parse_dates=['date'])
assets.set_index('date', inplace=True)
assets = assets[selected_assets_idx].abs()

print(f"Min. Date: {assets.index.min()}")
print(f"Max. Date: {assets.index.max()}")
print(f"Nº Rows: {assets.shape[0]}")
print(f"Nº Cols: {assets.shape[1]}\n")

assets.info()

# %%
assets.head()

# %%
returns = assets.diff()[1:] / assets.shift(1)[1:]
returns.head()

# %%
# Aqui preciso remover a primeira linha do df de fatores visto que eles já vem com retornos calculados
data = pd.concat([returns, sp500_returns, factors.iloc[1:]], axis=1) 
data

# %%
data.to_csv('../../data/multissd-full-data.csv')

# %% [markdown]
# ### Data for Experiment

# %%
print(data.loc['2023-03-16':'2024-01-01'].shape)
data.loc['2023-03-16':'2024-01-01'].head()

# %%
# Out-of-sample period from 01/01/2024 to 01/06/2024

print(data.loc['2024-01-01':'2024-06-01'].shape)
data.loc['2024-01-01':'2024-06-01'].head()

# %%
print(f"Nº out-of-sample days {data.loc['2023-03-16':'2024-01-01'].shape[0]}.")
print(f"Starting from {data.loc['2023-03-16':'2024-01-01'].index.min()} to {data.loc['2023-03-16':'2024-01-01'].index.max()}")
print()
print(f"Nº in-sample days {data.loc['2024-01-01':'2024-06-01'].shape[0]}.")
print(f"Starting from {data.loc['2024-01-01':'2024-06-01'].index.min()} to {data.loc['2024-01-01':'2024-06-01'].index.max()}")

# %% [markdown]
# ### Prepare Data

# %%
oos_prices = assets.loc['2024-01-01':'2024-06-01']
oos_prices = oos_prices.iloc[:,:10]
oos_prices

# %%
oos = data.loc['2024-01-01':'2024-06-01']
oos = oos.iloc[:,:10]
oos

# %%
scenarios = data.loc['2023-03-16':]
scenarios = scenarios.iloc[:,:10]
scenarios

# %%
benchmarks = data.loc['2023-03-16':]
benchmarks = benchmarks.iloc[:,-4:]
benchmarks

# %%
scenarios.shape, benchmarks.shape, oos_prices.shape, oos.shape

# %%
print(f"Scenarios Interval:  {scenarios.index.min()}, {scenarios.index.max()}")
print(f"Benchmarks Interval: {benchmarks.index.min()}, {benchmarks.index.max()}")

print(f"\nOOS Interval:        {oos.index.min()}, {oos.index.max()}")

# %% [markdown]
# ### Callback Classes

# %%
class MultiSSDLazyCallback(ConstraintCallbackMixin, LazyConstraintCallback, SolveCallback):
    
    def __init__(self, env):
        LazyConstraintCallback.__init__(self, env)
        ConstraintCallbackMixin.__init__(self)
        self.n_calls   = 0
        self.tolerance = 1e-6
        
    def __call__(self):

        if self.get_cplex_status() == self.status.optimal:
            self.n_calls += 1

            print('-' * 40)
            print(f"\n [INFO]: Running separation algorithm #{self.n_calls} ")
            n_assets      = self.scenarios.shape[1]
            n_scenarios   = self.scenarios.shape[0]
            curr_solution = self.make_complete_solution()                                                         
            V_value       = curr_solution[self.model.get_var_by_name('V')]                                     
            w_values      = [self.get_values(w.index) for w in self.w_vars]
            
            print(f"\n\tValue of V: {V_value:.5f}")
            formatted_values = [f"{w:.5f}" for w in w_values]
            print(f"\tWeights:   {formatted_values}\n")

            # Calculando Tail(R'w) para todo t.
            portfolio_returns = self.scenarios @ w_values 
            
            # Ordenar pelo valor do retorno e Imprimir formatado
            idx_returns = list(enumerate(portfolio_returns))
            sorted_idx_returns  = sorted(idx_returns, key=lambda x: x[1])
            for rank, (original_index, value) in enumerate(sorted_idx_returns, start=1):
                print(f"\t{rank:2}-th worst return: {value: .5f} (index {original_index})")
            print()
            
            # Ordena os retornos do portfólio
            sorted_p_returns = sorted(portfolio_returns)
            
            # Soma acumulada dos retornos do portfolio
            cum_p_returns = np.cumsum(sorted_p_returns)

            max_diff  = -np.inf
            max_index = None
            max_ret   = None

            for k, benchmark in enumerate(self.benchmarks):
                
                # Ordena os retornos do benchmark
                sorted_b_returns = benchmark

                # Soma acumulada dos retornos do benchmark
                cum_b_returns = np.cumsum(sorted_b_returns)

                #   Sum(Tail(R_1'w))                             - tau_1
                #   Sum(Tail(R_1'w) + Tail(R_2'w))               - tau_2
                #   Sum(Tail(R_1'w) + Tail(R_2'w) + Tail(R_3'w)) - tau_3      
                for s, ret in enumerate(cum_p_returns):

                    tau_s    = cum_b_returns[s]
                    rhs_expr = ret - tau_s

                    diff = V_value - rhs_expr
                    print(f"\t|Js| = {s + 1:2d}, C: {V_value:.5f} - ({ret:.5f}) <= ({tau_s:.5f}) (Violated by {diff:.5f})")
                    
                    if V_value > rhs_expr + self.tolerance:
                        
                        if diff > max_diff:
                            max_diff  = diff
                            max_index = s
                            max_ret   = ret

                if max_index is not None: 

                    print(f"\n[INFO]: SSD constraint violated to Vs_{max_index}\n")
                    print(f"[INFO]: Violation: {max_diff}\n")
                    
                    Vs = self.model.get_var_by_name(f"Vs_{k+1}_{s}")

                    # Obtém os índices dos |J| piores cenários
                    worst_scenario_indices = [idx for idx, _ in sorted_idx_returns[:max_index + 1]]  # max_index é zero-based
                    print(f"\tWorst Scenario Indices: {worst_scenario_indices}")
                    
                    # Soma os retornos desses cenários
                    cumulative_scenario = np.sum(self.scenarios[worst_scenario_indices, :], axis=0)
                    
                    # Construção explícita do corte
                    scenario_return = self.model.sum(cumulative_scenario[i] * self.w_vars[i] for i in range(n_assets))
                    rhs             = cum_b_returns[max_index]

                    formatted_values = [f"{ret:.5f}" for ret in cumulative_scenario]
                    print(f"\tWorst Scenario Returns: {formatted_values}")

                    print("\n\tCut to be added: ", end="")

                    
                    for i in range(n_assets):
                        print(f"{cumulative_scenario[i]:.5f} {self.w_vars[i].name} + ", end="")                    
                    print(f"1 {Vs} <= {rhs:.5f}\n")

                    # Adiciona restrição
                    cpx_lhs, sense, cpx_rhs = self.linear_ct_to_cplex(Vs <= scenario_return - rhs)

                    self.add(cpx_lhs, sense, cpx_rhs)

                    print(f"[INFO]: Violated constraint added.\n")
                    print(f"[INFO]: End of Separation Algorithm. ")
                    print('-' * 40 + '\n\n')

# %% [markdown]
# ### Model

# %%
def solve_multissd(scenarios, benchmarks, callback=False, verbose=False,):

    print("\n=== STARTING MULTI-SSD MODEL ===")
    model = Model(name='MultiSSD')

    # Variáveis
    model.parameters.preprocessing.presolve = 0
    model.parameters.mip.display = 4
    model.parameters.threads = 1
    model.parameters.emphasis.numerical = 1
    model.parameters.randomseed = 0
    model.parameters.emphasis.mip = 2
    model.parameters.simplex.tolerances.optimality = 1e-9
    model.parameters.simplex.tolerances.feasibility = 1e-9
    model.parameters.timelimit = 120
    model.parameters.mip.tolerances.absmipgap = 0
    model.parameters.mip.tolerances.mipgap = 0
    model.parameters.mip.tolerances.integrality = 0

    # # Variáveis
    K        = len(benchmarks)
    S_k      = list([len(tau) for tau in benchmarks])
    n_scenar = scenarios.shape[0]
    n_assets = scenarios.shape[1]


    print(f"DEBUG: Nº de Benchmarks: {K}")
    print(f"DEBUG: Nº de Bechmarks Scenarios: {S_k}")

    # Variáveis Básicas
    w  = model.continuous_var_list(n_assets, lb=0, ub=1, name='wl')

    # Variáveis Avançadas
    Vs = {}
    for k_idx in range(K):  
        k = k_idx + 1           
        for s in range(S_k[k_idx]):  
            Vs[(k, s+1)] = model.continuous_var(name=f"Vs_{k}_{s+1}", lb=-model.infinity, ub=model.infinity)

    V  = model.continuous_var(name="V", lb=-model.infinity, ub=model.infinity) 
    cb = model.binary_var(name='cb_temp')  

    # Restrições básicas
    model.add_constraint(model.sum(w) == 1, ctname="budget")
    
    # Restrições Avançadas
    for k_idx in range(K):
        k = k_idx + 1         
        for s in range(1, S_k[k_idx] + 1):
            model.add_constraint(V <= Vs[(k, s)], ctname=f"maxmin_{k}_{s}")
    
    for k_idx in range(K):  
        k  = k_idx + 1           # 1,2,3 para Vs
        Sk = S_k[k_idx]
        for s in range(1, Sk+1):  
            scenario_return = model.sum(w[i] * scenarios[s-1, i] for i in range(n_assets))
            model.add_constraint(Vs[(k,s)] <= scenario_return - benchmarks[0][0], ctname=f'ssd_b{k}_s{s}')


    model.maximize(V + cb)

    if verbose:
        for ct in model.iter_constraints():
            print(f"Name: {ct.name}, Expression: {ct.left_expr} {ct.sense} {ct.right_expr}")
            
    model.export_as_lp("../../models/toni-multissd-model.lp")

    if verbose: print(model.print_information())
    
    
    if callback:
        lazy_cb = model.register_callback(MultiSSDLazyCallback)
        lazy_cb.scenarios  = scenarios
        lazy_cb.benchmarks = benchmarks
        lazy_cb.w_vars     = w  
        lazy_cb.verbose    = verbose
    
    model.lazy_callback = lazy_cb
    
    print("\nIniciando processo de otimização...")
    
    sol = model.solve(log_output=True)
    
    if sol:
        optimized_weights = [sol[wi] for wi in w]
        weights           = np.array(optimized_weights)

        print("\n[INFO]: Solution Found:")
        print(f"\tV              {sol[V]}")
        print(f"\tBest Solution = {sol.get_objective_value()}")
        print(f"\tNº of Cuts    = {model.get_cuts()['user']}")
        print()
        for i, val in enumerate(optimized_weights):
            print(f"\tw[{i}] = {val}")
        
        return sol.get_objective_value(), weights
    else:
        print("No solutions found!")

# %%
def WFV(prices, returns, benchmarks, rebal_freq, sliding=True):
    
    import numpy as np
    import pandas as pd
    from datetime import datetime

    INITIAL_CAPITAL       = 100000

    portfolio_shares_held = pd.DataFrame()
    weights_invested      = pd.DataFrame()
    rebalances_df         = pd.DataFrame()
    valuation_df          = pd.DataFrame()
    shares_df             = pd.DataFrame()
    norm_portfolio_df     = pd.DataFrame(columns=["portfolio_norm"])  # ← ADIÇÃO

    print('---------------------------------------------------------------')
    print('[INFO]: Simulation Started...\n')
    
    initial_train_days = 200
    validation_days    = 1
    rebalance_freq     = rebal_freq

    data_length = len(returns)
    print(f"DEBUG data_length: {data_length}")
    print(f"DEBUG initial_train_days: {initial_train_days}")
    max_steps   = data_length - initial_train_days
    print(f"DEBUG max_steps: {max_steps}")


    last_share = None 

    for step in range(0, max_steps, validation_days):

        train_start     = step if sliding else 0
        train_end       = train_start + initial_train_days

        train           = returns.iloc[train_start:train_end]
        # train_bench     = benchmark.iloc[train_start:train_end]

        valid           = returns.iloc[train_end-1:train_end]  
        # valid_benchmark = benchmark.iloc[train_end-1:train_end]  


        print(f"{range(0, max_steps, validation_days)}")
        print(f"DEBUG - TRAIN START: {train.index.min()}")
        print(f"DEBUG - TRAIN START: {train.index.max()}")
        print(f"DEBUG - VALID START: {valid.index.min()}")
        print(f"DEBUG - VALID END:   {valid.index.max()}")


        # TODO
        # para cada benchmark faça:
        # divida as proporções de treino APENAS dos benchmarks
        # adicione as proporções em uma lista
        # passe a lista como parametro
        train_benchs = list()
        for benchmark in benchmarks:
            train_bench     = benchmark.iloc[train_start:train_end]
            train_benchs.append(np.array(train_bench))

        func_obj, weights_arr = solve_multissd(np.array(train), train_benchs, callback=True, verbose=False)
        
        weights_opt = pd.DataFrame([weights_arr], columns=valid.columns, index=valid.index)

        print(f"Day: {step + 1} ({valid.index.min()})")
        print(f"\tSum proportions: {np.sum(weights_arr)*100}%")
        print(f"\tFUNÇÃO OBJETIVO: {func_obj}")


        # ============================================================
        # SIMULATION
        # ============================================================

        price = np.array(prices.loc[prices.index[step], :])

        # ============================================================
        # DIA 0 — primeiro dia da simulação
        # ============================================================
        if step == 0:
            valuation     = (weights_arr * INITIAL_CAPITAL)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

        # ============================================================
        # DIA DE REBALANCEAMENTO
        # ============================================================
        elif step % rebalance_freq == 0:
            
            print(f'\tToday is a rebalancing day.')

            valuation_normal = (last_share * price)
            total_value      = np.sum(valuation_normal)

            print(f"\tValuation before rebalance: {total_value}")

            valuation     = (weights_arr * total_value)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

        # ============================================================
        # DIA SEM REBALANCEAMENTO
        # ============================================================
        else:
            share     = last_share
            valuation = share * price

        # ============================================================
        # Armazenamento
        # ============================================================
        date_idx = valid.index[0]

        valuation_df     = pd.concat([valuation_df,pd.DataFrame([valuation], index=[date_idx], columns=valid.columns)])
        shares_df        = pd.concat([shares_df, pd.DataFrame([share], index=[date_idx], columns=valid.columns)])
        weights_invested = pd.concat([weights_invested, weights_opt])

        norm_portfolio_df.loc[date_idx, "portfolio_norm"] = (np.sum(valuation) / INITIAL_CAPITAL)

        last_share = share

        print(f"\tPortfolio Value: {np.sum(valuation)}")
        print(f"\tNorm Portfolio: {np.sum(valuation)/INITIAL_CAPITAL}")
        print('---------------------------------------------------------------\n')


    return (norm_portfolio_df, weights_invested, rebalances_df, valuation_df, shares_df)


# %%
type(benchmarks['SP500'])

# %%
benchmarks_list = list()
benchmarks_list = [benchmarks['SP500']]

# %%
print(type(oos_prices))
print(type(scenarios))
print(type(benchmarks_list))

# %%
for benchmark in benchmarks_list:
    print(benchmark)
    #benchmark.iloc[1:2]

# %%


if __name__ == "__main__":
    

    portfolio, weightsInvested, weightsRebalance, portfolioValuation, portfolioShares = WFV(oos_prices,
                                                                                            scenarios,
                                                                                            benchmarks_list,
                                                                                            21, 
                                                                                            sliding=True)

    print('==========================================================')
    print('Finalising simulation...')

# %%
print(portfolio.shape)
print(portfolio.head())



# %%
print(weightsRebalance.shape)
print(weightsRebalance.head(40))

# %%
print(portfolioValuation.shape)
print(portfolioValuation.head(40))

# %%
print(weightsInvested.shape)
print(weightsInvested.head(40))

# %%
print(portfolioShares.shape)
print(portfolioShares.head(40))

# %% [markdown]
# ## Plots

# %%
def plot_portfolio_comparison(portfolio):
    """
    Plota o comparativo de performance entre o portfólio (estratégia)
    e o benchmark S&P 500, ambos normalizados.
    """
    plt.figure(figsize=(20, 10))

    plt.plot(portfolio.index, portfolio["portfolio_norm"], label="SSD Toni") # Estratégia
    plt.plot(portfolio.index, portfolio["SP500_norm"], label="SP500")        # Benchmark

    if "Risk free rate" in portfolio.columns: plt.plot( portfolio.index, portfolio["Risk free rate"], label="Risk free rate", linestyle="--" )

    plt.title("Comparativo de Performance dos Portfólios", fontsize=20)
    plt.xlabel("Data", fontsize=16)
    plt.ylabel("Valor normalizado",  fontsize=16)

    plt.legend(fontsize=14)
    plt.grid(True, alpha=0.3)   # grid mais suave
    plt.xticks(rotation=45)    # datas em 45 graus

    ax = plt.gca()
    for spine in ax.spines.values():
        spine.set_visible(False)
    

    ax.tick_params(axis='both', colors='gray', labelsize=14)
    plt.savefig("multissd_portfolio_comparison.png", dpi=300)
    plt.tight_layout()
    plt.show()


# %%
sp500_slice = data.loc['2023-10-31':'2023-11-30', 'SP500'].abs()
sp500_norm = sp500_slice / sp500_slice.iloc[0]
portfolio['SP500_norm'] = sp500_norm
portfolio['Risk free rate'] = 1.0

portfolio

# %%
plot_portfolio_comparison(portfolio)

# %%



