# %% [markdown]
# ### Multi-SSD
# 
# The SSD formulation can be easily extended to include dominance of multiple reference distributions. 
# In summary, we are looking for a single portfolio that dominates multiple benchmarks with respect to SSD. 
# Instead of a single set containing $S$ scenarios, let there be $K$ non-empty scenario sets 
# $\{1,\ldots,S^k\}$, $k = 1,\ldots,K$, with $S^k$ scenarios each. 
# For each set let there be a corresponding reference distribution $I^k$ with $S^k$ discrete returns.
# 
# For each asset $i = 1,\ldots,N$, let $r^{k}_{is}$ be the return on scenario $s = 1,\ldots,S^k$. 
# Let $\hat{\tau}^k_s = \mathrm{Tail}^L_{\frac{s}{S^k}}(I^k)$ for $s = 1,\ldots,S^k$, $k = 1,\ldots,K$. Then let:
# \begin{equation}
# \mathcal{V}^k_s = \mathrm{Tail}^L_{s/S^k}(P) - \hat{\tau}^k_s, 
# \quad s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{equation}
# 
# Let $\mu^k_s > 0$ be the weight that we attach to $\mathcal{V}^k_s$. Then a suitable optimisation program 
# for solving the Multi-SSD problem is:
# 
# \begin{equation}
# \max \ \mathcal{V}
# \end{equation}
# 
# subject to:
# \begin{align}
# \mathcal{V} &\leq \mathcal{V}^k_s, && s = 1,\ldots,S^k,\; k = 1,\ldots,K, \\
# \mathcal{V}^k_s &\leq \frac{1}{S^k} \sum_{j \in \mathcal{J}} \sum_{i=1}^N r_{ij} w_i - \hat{\tau}^k_s, 
# && \mathcal{J} \subseteq \{1,\ldots,S^k\},\; |\mathcal{J}| = s, \\
# \sum_{i=1}^N w_i &= 1, \\
# \mathcal{V}^k_s &\in \mathbb{R}, && s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{align}
# 
# For the scaled version of the Multi-SSD formulation we replace the first constraints with:
# \begin{equation}
# \frac{s}{S^k} \mathcal{V} \leq \mathcal{V}^k_s, 
# \quad s = 1,\ldots,S^k,\; k = 1,\ldots,K.
# \end{equation}
# %% [markdown]
# ### Experiments
# 
# 
# Basic experiment:
#  - Scaled SSD model
#  - 200 days in-sample
#  - Not adjusted prices
#  - Data for S&P500 companies
#  - Rebalancing every 21 days
#  - Out-of-sample period from 01/01/2024 to 01/06/2024
#  - No transaction costs, or lot sizes
# 
# Benchmarks: S&P500 index and HML, SMB and CMA factor returns.
# 
#  - CMA: Conservative minus Aggressive
#  - HML: High minus Low
#  - SMB: Small minus Big
# 4 rebalances
# %% [markdown]
# ### Imports
# %%
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Qt5Agg") # ou Qt5Agg


import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.dates as mdates
from matplotlib.ticker import MultipleLocator

import cplex
from docplex.mp.model import Model
from cplex.callbacks import UserCutCallback, LazyConstraintCallback, SolveCallback
from docplex.mp.callbacks.cb_mixin import ConstraintCallbackMixin

pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 200)
pd.set_option('expand_frame_repr', False)


plt.rcParams["font.family"] = "Arial"
sns.set(
    font_scale=1.1,
    rc={
        "figure.figsize": (10, 6),
        "axes.facecolor": "white",
        "figure.facecolor": "white",
        "grid.color": "#dddddd",
        "grid.linewidth": 0.5,
        "lines.linewidth": 1.5,
        "text.color": "#333333",
        "xtick.color": "#666666",
        "ytick.color": "#666666",
    },
)

# %% [markdown]
# ### Returns Data
# %%
data = pd.read_csv('../../data/multissd_data.csv', parse_dates=['date'])
data.set_index('date', inplace=True)
# %%
asset_prices = data.pivot(columns="asset", values="adjClose")
asset_prices.columns.name = None
print(asset_prices.shape)
# %%
selected_assets_idx = ['0157B1', '03B8CF', '055018', '061366', '0624BE', '063384', '067779', '06EF42', '07EC43', '095294']
selected_assets     = ['AMZN','MMM','COF','FSLR','ANF','BG','CCL','DHI','CTSH','DXC']

print(asset_prices.shape)
asset_prices        = asset_prices[selected_assets_idx].abs()
asset_prices

# %%
# 2023-11-23 - Thanksgiving holiday
# 2024-03-29 - Good Friday

asset_prices[asset_prices.isna().any(axis=1)]
# %%
asset_prices.dropna(inplace=True)# Fill NaN data with las valid value
# %%
print(f"Min. Date: {asset_prices.index.min()}")
print(f"Max. Date: {asset_prices.index.max()}")
print(f"Nº Rows:   {asset_prices.shape[0]}")
print(f"Nº Cols:   {asset_prices.shape[1]}\n")

asset_prices.info()
# %%
asset_returns = asset_prices.diff()[1:] / asset_prices.shift(1)[1:]

print(f"Min. Date: {asset_returns.index.min()}")
print(f"Max. Date: {asset_returns.index.max()}")
print(f"Nº Rows:   {asset_returns.shape[0]}")
print(f"Nº Cols:   {asset_returns.shape[1]}\n")

asset_returns.info()
# %% [markdown]
# ### Benchmarks Data
# %%
factor_returns = pd.read_csv('../../data/extracted_factors_data.csv', parse_dates=['date'])
factor_returns.set_index('date', inplace=True)

print(f"Min. Date: {factor_returns.index.min()}")
print(f"Max. Date: {factor_returns.index.max()}")
print(f"Nº Rows:   {factor_returns.shape[0]}")
print(f"Nº Cols:   {factor_returns.shape[1]}\n")

factor_returns.info()
# %%
sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
sp500_prices.set_index('date', inplace=True)

print(f"Min. Date: {sp500_prices.index.min()}")
print(f"Max. Date: {sp500_prices.index.max()}")
print(f"Nº Rows:   {sp500_prices.shape[0]}")
print(f"Nº Cols:   {sp500_prices.shape[1]}\n")

sp500_prices.info()
# %%
sp500_returns = sp500_prices.diff()[1:] / sp500_prices.shift(1)[1:]

print(f"Min. Date: {sp500_returns.index.min()}")
print(f"Max. Date: {sp500_returns.index.max()}")
print(f"Nº Rows:   {sp500_returns.shape[0]}")
print(f"Nº Cols:   {sp500_returns.shape[1]}\n")

sp500_returns.info()
# %%
# Aqui preciso remover a primeira linha do df de fatores visto que eles já vem com retornos calculados
data_returns = pd.concat([asset_returns, sp500_returns, factor_returns.iloc[1:]], axis=1)

print(f"Min. Date: {data_returns.index.min()}")
print(f"Max. Date: {data_returns.index.max()}")
print(f"Nº Rows:   {data_returns.shape[0]}")
print(f"Nº Cols:   {data_returns.shape[1]}\n")

data_returns.to_csv('../../data/multissd-returns-data.csv')

data_returns.info()
# %%
data_returns.head()
# %% [markdown]
# ### Data for Experiment
# %%
df = data_returns.loc['2023-03-16':'2024-01-02']

print(df.shape)
df
# %%
# Out-of-sample period from 2024-01-01 to 2024-06-01

print(data_returns.loc['2024-01-01':'2024-05-31'].shape)
data_returns.loc['2024-01-01':'2024-05-31'].head()
# %%
print("==== SPLIT SUMMARY ====")
print(f"Nº out-of-sample days {data_returns.loc['2023-03-16':'2024-01-02'].shape[0]}.")
print(f"Starting from {data_returns.loc['2023-03-16':'2024-01-01'].index.min()} to {data_returns.loc['2023-03-16':'2024-01-02'].index.max()}")
print()
print(f"Nº in-sample days {data_returns.loc['2024-01-01':'2024-06-01'].shape[0]}.")
print(f"Starting from {data_returns.loc['2024-01-01':'2024-06-01'].index.min()} to {data_returns.loc['2024-01-01':'2024-06-01'].index.max()}")
# %% [markdown]
# ### Prepare Data
# %%
in_sample_days = 200
oos_start      = '2024-01-01'
oos_end        = '2024-06-01'
# %%
# oos Returns
oos_returns = data_returns.loc[oos_start:oos_end]
oos_returns.head(10)
# %%
# oos Prices
oos_prices = asset_prices.loc[oos_start:oos_end]
oos_prices = oos_prices.iloc[:,:10]
oos_prices.head(10)
# %%
oos_first_day = oos_returns.index.min()
pos = data_returns.index.get_loc(oos_first_day)
in_sample_returns = data_returns.iloc[pos - 200 : pos + 1]
in_sample_returns.head(10)
# %%
in_sample_first_day = in_sample_returns.index.min()
scenarios = data_returns.loc[in_sample_first_day:]
scenarios = scenarios.iloc[:,:10]
scenarios
# %%
benchmarks = data_returns.loc[in_sample_first_day:]
benchmarks = benchmarks.iloc[:,-4:]
benchmarks
# %%
# benchmarks_list = [benchmarks['SMB'],
                   # benchmarks['HML'],
                   # benchmarks['CMA'],
                   # benchmarks['SMB'],
                # ]
benchmarks_list = [benchmarks['SP500']]
benchmarks_list
# %%
# Segundo a estrategia de Arbex, o ultimo dia do In-sample é também é o primeiro do Out-of-sample.
# Isso justifica o fato de In-sample data ter 201 amostras e não 200 como a quantidade de dias

print('\033[93m[INFO]: Data Simulation Summary\n\033[0m')
print(f"\tdata_length:         {len(scenarios)}")
print(f"\tin sample days:      {in_sample_days}\n")
print(f"\tNº of Benchmarks:    {len(benchmarks_list)}")
print(f"\tBenchmarks:          {[s.name for s in benchmarks_list]}\n")
print(f"\tScenarios data info: {len(scenarios)} samples between {scenarios.index.min()} and {scenarios.index.max()}")
print(f"\tIn-sample data info: {len(in_sample_returns)} samples between {in_sample_returns.index.min()} and {in_sample_returns.index.max()}")
print(f"\tOut-of-sample info:  {len(oos_returns)} samples between {oos_returns.index.min()} and {oos_returns.index.max()}")
# %%
scenarios.shape, benchmarks.shape, in_sample_returns.shape, oos_prices.shape, oos_returns.shape
# %% [markdown]
# ### PortSim Data
# %%
portsim_prices_data       = pd.read_csv('../../data/portsim_asset_prices.csv', index_col=0)
portsim_prices_data.index = scenarios.index

# Fill NaN data with 0 value
# portsim_prices_data.fillna(0, inplace=True)

# Backward Fill NaN data with last value
# portsim_prices_data = portsim_prices_data.bfill()

# Backward Fill + Foward Fill NaN data with last value
portsim_prices_data = portsim_prices_data.ffill().bfill()



print(f"Min. Date: {portsim_prices_data.index.min()}")
print(f"Max. Date: {portsim_prices_data.index.max()}")
print(f"Nº Rows:   {portsim_prices_data.shape[0]}")
print(f"Nº Cols:   {portsim_prices_data.shape[1]}\n")

portsim_prices_data.info()
# %%
portsim_prices_data
# %%
portsim_returns_data       = pd.read_csv('../../data/portsim_asset_returns.csv', index_col=0)
portsim_returns_data.index = scenarios.index

print(f"Min. Date: {portsim_returns_data.index.min()}")
print(f"Max. Date: {portsim_returns_data.index.max()}")
print(f"Nº Rows:   {portsim_returns_data.shape[0]}")
print(f"Nº Cols:   {portsim_returns_data.shape[1]}\n")

portsim_returns_data.info()
# %%
portsim_returns_data
# %%
portsim_oos_prices = portsim_prices_data.loc[oos_start:oos_end]
portsim_oos_prices = portsim_oos_prices

print(f"Min. Date: {portsim_oos_prices.index.min()}")
print(f"Max. Date: {portsim_oos_prices.index.max()}")
print(f"Nº Rows:   {portsim_oos_prices.shape[0]}")
print(f"Nº Cols:   {portsim_oos_prices.shape[1]}\n")

portsim_oos_prices.info()
# %%
portsim_oos_prices.head()
# %%
portsim_oos_returns = portsim_returns_data.loc[oos_start:oos_end]

print(f"Min. Date: {portsim_oos_returns.index.min()}")
print(f"Max. Date: {portsim_oos_returns.index.max()}")
print(f"Nº Rows:   {portsim_oos_returns.shape[0]}")
print(f"Nº Cols:   {portsim_oos_returns.shape[1]}\n")

portsim_oos_prices.info()
# %%
portsim_oos_returns.head(10)
# %%
portsim_oos_first_day = portsim_oos_returns.index.min()
pos = portsim_returns_data.index.get_loc(portsim_oos_first_day)
portsim_in_sample_returns = portsim_returns_data.iloc[pos - 200 : pos + 1]

print(f"Min. Date: {portsim_in_sample_returns.index.min()}")
print(f"Max. Date: {portsim_in_sample_returns.index.max()}")
print(f"Nº Rows:   {portsim_in_sample_returns.shape[0]}")
print(f"Nº Cols:   {portsim_in_sample_returns.shape[1]}\n")

portsim_in_sample_returns.info()
# %%
portsim_in_sample_returns.head(10)
# %%
portsim_prices_data[portsim_prices_data.isna().any(axis=1)]
# %%
portsim_returns_data[portsim_returns_data.isna().any(axis=1)]
# %%
portsim_oos_prices[portsim_oos_prices.isna().any(axis=1)]

# %%
portsim_in_sample_returns[portsim_in_sample_returns.isna().any(axis=1)]
# %%
# 600 < 500 < 400
n_cols                    = 400

portsim_prices_data       = portsim_prices_data.iloc[:, :n_cols]
portsim_returns_data      = portsim_returns_data.iloc[:, :n_cols]
portsim_oos_prices        = portsim_oos_prices.iloc[:, :n_cols]
portsim_in_sample_returns = portsim_in_sample_returns.iloc[:, :n_cols]
portsim_oos_returns       = portsim_oos_returns.iloc[:, :n_cols]
# %%
portsim_prices_data.shape, portsim_returns_data.shape, portsim_in_sample_returns.shape, portsim_oos_prices.shape, portsim_oos_returns.shape
# %% [markdown]
# ### Callback Classes
# %%
class MultiSSDLazyCallback(ConstraintCallbackMixin, LazyConstraintCallback, SolveCallback):
    
    def __init__(self, env):
        LazyConstraintCallback.__init__(self, env)
        ConstraintCallbackMixin.__init__(self)
        self.n_calls   = 0
        self.tolerance = 1e-6
        self.debug = False
        self.cuts_debug = False
        
    def __call__(self):

        if self.get_cplex_status() == self.status.optimal:
            self.n_calls += 1

            if self.cuts_debug: print(f"\n [INFO]: Running separation algorithm #{self.n_calls} ")
            n_assets      = self.scenarios.shape[1]
            n_scenarios   = self.scenarios.shape[0]
            curr_solution = self.make_complete_solution()                                                         
            V_value       = curr_solution[self.model.get_var_by_name('V')]                                     
            w_values      = [self.get_values(w.index) for w in self.w_vars]

            if self.cuts_debug:
                print(f"\n\t{'V':<22}: {V_value:.5f}")
                formatted_values = [f"{w:.5f}" for w in w_values]
                print(f"\t{'Weights':<22}: {formatted_values}")

            # Calculando Tail(R'w) para todo t.
            portfolio_returns = self.scenarios @ w_values 
            
            # Ordenar pelo valor do retorno e Imprimir formatado
            idx_returns = list(enumerate(portfolio_returns))
            sorted_idx_returns  = sorted(idx_returns, key=lambda x: x[1])

            if self.debug:
                for rank, (original_index, value) in enumerate(sorted_idx_returns, start=1):
                    print(f"\t{rank:2}-th worst return: {value: .5f} (index {original_index})")
                print()
            
            # Ordena os retornos do portfólio
            sorted_p_returns = sorted(portfolio_returns)
            
            # Soma acumulada dos retornos do portfolio
            cum_p_returns = np.cumsum(sorted_p_returns)

            max_diff  = -np.inf
            max_index = None
            max_ret   = None

            for k, benchmark in enumerate(self.benchmarks):
                
                # Ordena os retornos do benchmark
                sorted_b_returns = benchmark

                # Soma acumulada dos retornos do benchmark
                cum_b_returns = np.cumsum(sorted_b_returns)

                #   Sum(Tail(R_1'w))                             - tau_1
                #   Sum(Tail(R_1'w) + Tail(R_2'w))               - tau_2
                #   Sum(Tail(R_1'w) + Tail(R_2'w) + Tail(R_3'w)) - tau_3      
                for s, ret in enumerate(cum_p_returns):

                    tau_s    = cum_b_returns[s]
                    rhs_expr = ret - tau_s

                    diff = V_value - rhs_expr
                    if self.debug: print(f"\t|Js| = {s + 1:2d}, C: {V_value:.5f} - ({ret:.5f}) <= ({tau_s:.5f}) (Violated by {diff:.5f})")
                    
                    if V_value > rhs_expr + self.tolerance:
                        
                        if diff > max_diff:
                            max_diff  = diff
                            max_index = s
                            max_ret   = ret

                if max_index is not None: 

                    if self.cuts_debug:
                        print(f"\t{'Violated constraint':<22}: Vs_{max_index}")
                        print(f"\t{'Violation':<22}: {max_diff}")
                    
                    Vs = self.model.get_var_by_name(f"Vs_{k+1}_{s}")

                    # Obtém os índices dos |J| piores cenários
                    worst_scenario_indices = [idx for idx, _ in sorted_idx_returns[:max_index + 1]]  # max_index é zero-based
                    if self.debug: print(f"\tWorst Scenario Indices: {worst_scenario_indices}")
                    
                    # Soma os retornos desses cenários
                    cumulative_scenario = np.sum(self.scenarios[worst_scenario_indices, :], axis=0)
                    
                    # Construção explícita do corte
                    scenario_return = self.model.sum(cumulative_scenario[i] * self.w_vars[i] for i in range(n_assets))
                    rhs             = cum_b_returns[max_index]

                    formatted_values = [f"{ret:.5f}" for ret in cumulative_scenario]
                    if self.debug: print(f"\tWorst Scenario Returns: {formatted_values}")
                    
                    if self.cuts_debug:
                        print(f"\t{'Cut to be added':<22}: ", end="")
                        for i in range(n_assets):
                            print(f"{cumulative_scenario[i]:.5f} {self.w_vars[i].name} + ", end="")                    
                        print(f"1 {Vs} <= {rhs:.5f}\n")

                    # Adiciona restrição
                    cpx_lhs, sense, cpx_rhs = self.linear_ct_to_cplex(Vs <= scenario_return - rhs)

                    self.add(cpx_lhs, sense, cpx_rhs)

                    if self.cuts_debug:
                        print(f"\t\033[92m> Violated constraint added.\033[0m\n")
                        print(f"\t> End of Separation Algorithm.")
                        print('-' * 40)
                    break
# %% [markdown]
# ### Model
# %%
def solve_multissd(scenarios, benchmarks, callback=False, verbose=False,):
    model = Model(name='MultiSSD')

    # Variáveis
    model.parameters.preprocessing.presolve = 0
    model.parameters.mip.display = 4
    model.parameters.threads = 1
    model.parameters.emphasis.numerical = 1
    model.parameters.randomseed = 0
    model.parameters.emphasis.mip = 2
    model.parameters.simplex.tolerances.optimality = 1e-9
    model.parameters.simplex.tolerances.feasibility = 1e-9
    model.parameters.timelimit = 120
    model.parameters.mip.tolerances.absmipgap = 0
    model.parameters.mip.tolerances.mipgap = 0
    model.parameters.mip.tolerances.integrality = 0

    # # Variáveis
    K        = len(benchmarks)
    S_k      = list([len(tau) for tau in benchmarks])
    n_scenar = scenarios.shape[0]
    n_assets = scenarios.shape[1]


    print(f"\tDEBUG: Nº de Benchmarks: {K}")
    print(f"\tDEBUG: Nº de Bechmarks Scenarios: {S_k}")

    # Variáveis Básicas
    w  = model.continuous_var_list(n_assets, lb=0, ub=1, name='wl')

    # Variáveis Avançadas
    Vs = {}
    for k_idx in range(K):  
        k = k_idx + 1           
        for s in range(S_k[k_idx]):  
            Vs[(k, s+1)] = model.continuous_var(name=f"Vs_{k}_{s+1}", lb=-model.infinity, ub=model.infinity)

    V  = model.continuous_var(name="V", lb=-model.infinity, ub=model.infinity) 
    cb = model.binary_var(name='cb_temp')  

    # Restrições básicas
    model.add_constraint(model.sum(w) == 1, ctname="budget")
    
    # Restrições Avançadas
    for k_idx in range(K):
        k = k_idx + 1         
        for s in range(1, S_k[k_idx] + 1):
            model.add_constraint(V <= Vs[(k, s)], ctname=f"maxmin_{k}_{s}")
    
    for k_idx in range(K):  
        k  = k_idx + 1           # 1,2,3 para Vs
        Sk = S_k[k_idx]
        for s in range(1, Sk+1):  
            scenario_return = model.sum(w[i] * scenarios[s-1, i] for i in range(n_assets))
            model.add_constraint(Vs[(k,s)] <= scenario_return - benchmarks[0][0], ctname=f'ssd_b{k}_s{s}')


    model.maximize(V + cb)

    if verbose:
        for ct in model.iter_constraints():
            print(f"Name: {ct.name}, Expression: {ct.left_expr} {ct.sense} {ct.right_expr}")
            
    model.export_as_lp("../../models/toni-multissd-model.lp")

    if verbose: print(model.print_information())
    
    
    if callback:
        lazy_cb = model.register_callback(MultiSSDLazyCallback)
        lazy_cb.scenarios  = scenarios
        lazy_cb.benchmarks = benchmarks
        lazy_cb.w_vars     = w  
        lazy_cb.verbose    = verbose
    
    model.lazy_callback = lazy_cb
    
    print("\t\nInitializing Optimization Process...")
    print(40*"-")
    
    sol = model.solve(log_output=False)
    
    if sol:
        optimized_weights = [sol[wi] for wi in w]
        weights           = np.array(optimized_weights)

        print("\t\n[INFO]: Solution Found:")
        print(f"\tV              {sol[V]}")
        print(f"\tBest Solution = {sol.get_objective_value()}")
        print(f"\tNº of Cuts    = {model.get_cuts()['user']}")
        print()
        for i, val in enumerate(optimized_weights):
            print(f"\tw[{i}] = {val}")
        
        return sol.get_objective_value(), weights
    else:
        print("No solutions found!")
# %%
def WFV(prices, scenarios, in_sample_data, benchmarks, rebal_freq, sliding=True):

    import numpy as np
    import pandas as pd
    from datetime import datetime

    INITIAL_CAPITAL       = 100000

    portfolio_shares_held = pd.DataFrame()
    weights_invested      = pd.DataFrame()
    rebalances_df         = pd.DataFrame()
    valuation_df          = pd.DataFrame()
    shares_df             = pd.DataFrame()
    norm_portfolio_df     = pd.DataFrame(columns=['MultiSSD'])


    print(60*'=')
    print('\033[93m[INFO]: Data Simulation Summary\n\033[0m')
    print(f"\tdata_length:         {len(scenarios)}")
    print(f"\tin sample days:      {len(in_sample_data)}\n")
    print(f"\tScenarios data info: {len(scenarios)} samples between {scenarios.index.min()} and {scenarios.index.max()}")
    print(f"\tIn-sample data info: {len(in_sample_data)} samples between {in_sample_data.index.min()} and {in_sample_data.index.max()}")
    print(f"\tOut-of-sample info:  {len(portsim_oos_returns)} samples between {portsim_oos_returns.index.min()} and {portsim_oos_returns.index.max()}")
    print(40 * "-" + "\n")
    
    print('\033[93m[INFO]: Simulation Started...\n\033[0m')
    print("\tModel: Multi SSD")
    
    in_sample_days  = len(in_sample_data)
    validation_days = 1                         # Quantidade de dias que vou avaliar no WFV
    rebalance_freq  = rebal_freq
    debug           = True

    data_length = len(scenarios)
    max_steps   = data_length - in_sample_days # Tamanho total dos dados menos os 200 dias

    last_share = None 

    for step in range(0, max_steps, validation_days):

        train_start     = step if sliding else 0
        train_end       = train_start + in_sample_days
        train           = scenarios.iloc[train_start:train_end]
        # train_bench     = benchmark.iloc[train_start:train_end]
        valid           = scenarios.iloc[train_end-1:train_end]  
        # valid_benchmark = benchmark.iloc[train_end-1:train_end]    

        # TODO
        # para cada benchmark faça:
        # divida as proporções de treino APENAS dos benchmarks
        # adicione as proporções em uma lista
        # passe a lista como parametro
        train_benchs = list()
        for benchmark in benchmarks:
            train_bench     = benchmark.iloc[train_start:train_end]
            train_benchs.append(np.array(train_bench))

        func_obj, weights_arr = solve_multissd(np.array(train), train_benchs, callback=True, verbose=False)
        
        weights_opt = pd.DataFrame([weights_arr], columns=valid.columns, index=valid.index)

        print(f"\n\t\033[93mDay: {step + 1} ({valid.index.min()})\033[0m")
        print(f"\tSum proportions: {np.sum(weights_arr)*100}%")
        print(f"\tFUNÇÃO OBJETIVO: {func_obj}")

        
        # ============================================================
        # SIMULATION
        # ============================================================

        price = np.array(prices.loc[prices.index[step], :])

        # ============================================================
        # DIA 0 — primeiro dia da simulação
        # ============================================================
        if step == 0:
            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            valuation     = (weights_arr * INITIAL_CAPITAL)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])
        
        # ============================================================
        # DIA DE REBALANCEAMENTO
        # ============================================================
        elif step % rebalance_freq == 0:
          
            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            valuation_normal = (last_share * price)
            total_value      = np.sum(valuation_normal)

            print(f"\tValuation before rebalance: {total_value}")

            valuation     = (weights_arr * total_value)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])
            
        # ============================================================
        # DIA SEM REBALANCEAMENTO
        # ============================================================
        else:
            share     = last_share
            valuation = share * price
        
        # ============================================================
        # Armazenamento
        # ============================================================
        date_idx = valid.index[0]

        valuation_df     = pd.concat([valuation_df,pd.DataFrame([valuation], index=[date_idx], columns=valid.columns)])
        shares_df        = pd.concat([shares_df, pd.DataFrame([share], index=[date_idx], columns=valid.columns)])
        weights_invested = pd.concat([weights_invested, weights_opt])

        norm_portfolio_df.loc[date_idx, "MultiSSD"] = (np.sum(valuation) / INITIAL_CAPITAL)

        last_share = share

        print(f"\tPortfolio Value: {np.sum(valuation)}")
        print(f"\tNorm Portfolio:  {np.sum(valuation)/INITIAL_CAPITAL}")
        print('---------------------------------------------------------------\n')


    return (norm_portfolio_df, weights_invested, rebalances_df, valuation_df, shares_df)

# %%
# %%time

if __name__ == "__main__":
    

    portfolio, weightsInvested, weightsRebalance, portfolioValuation, portfolioShares = WFV(portsim_oos_prices,
                                                                                            portsim_returns_data,
                                                                                            portsim_in_sample_returns,
                                                                                            benchmarks_list,
                                                                                            21,
                                                                                            sliding=True)

    print('==========================================================')
    print('Finalising simulation...')
# %%
print(portfolio.shape)
print(portfolio.head())
# %%
print(weightsRebalance.shape)
print(weightsRebalance.head())
# %%
print(portfolioValuation.shape)
print(portfolioValuation.head())

# %%
print(weightsInvested.shape)
print(weightsInvested.head())

# %%
print(portfolioShares.shape)
print(portfolioShares.head())

# %% [markdown]
# ### Normalize Bechmarks prices
# %%
sp500_slice = sp500_prices.loc[oos_start:oos_end]
sp500_norm = sp500_slice / sp500_slice.iloc[0]
portfolio['SP500'] = sp500_norm

# hml_slice = factor_returns[['HML']].loc[oos_start:oos_end]
# hml_norm  = hml_slice / hml_slice.iloc[0]
# portfolio['HML'] = hml_norm

portfolio['riskFreeRate'] = 1.0

# %%
portsim_norm_portfolio_data = pd.read_csv('../../data/portsim_norm_portfolio_data.csv', parse_dates=['Date']).iloc[:-1]
portsim_norm_portfolio_data.set_index('Date', inplace=True)
portsim_norm_portfolio_data
# %%
portfolio['SMB'] = portsim_norm_portfolio_data['SMB']
# portfolio['SMB'] = portsim_norm_portfolio_data['SMB']
# portfolio['CMA'] = portsim_norm_portfolio_data['CMA']

print()
print(portfolio.head())
# %% [markdown]
# ## Plots
# %%

def plot_portfolio_comparison(portfolio, force_background=False):
    """
    Plota todas as séries de um DataFrame ao longo do tempo.
    Cada coluna será uma linha no gráfico.
    """

    portfolio.index = pd.to_datetime(portfolio.index)

    plt.figure(figsize=(15, 9))
    ax = plt.gca()

    if force_background:
        ax.set_facecolor("white")
        ax.figure.set_facecolor("white")

    # guarda última data para posicionar labels
    last_x = portfolio.index[-1]

    for col in portfolio.columns:
        y = portfolio[col]

        if col.lower() == "riskFreeRate":
            ax.plot(
                portfolio.index,
                y,
                linestyle="--",
                alpha=0.9
            )
        else:
            ax.plot(
                portfolio.index,
                y,
                alpha=0.9
            )

        ax.text(
            last_x,
            y.iloc[-1],
            f" {col}",
            va="center",
            fontsize=12
        )

    plt.title("OOS Performance", fontsize=20)
    # plt.xlabel("Period", fontsize=16)
    plt.ylabel("Normalised Values", fontsize=16)

    ax.yaxis.set_major_locator(MultipleLocator(0.05))

    ax.xaxis.set_major_locator(mdates.MonthLocator(bymonthday=[1, 15]))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))

    plt.xticks(rotation=45)

    plt.grid(True, alpha=0.6)

    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.tick_params(axis='both', colors='gray', labelsize=14)

    plt.tight_layout()
    plt.show()
# %%
# plot_portfolio_comparison(portfolio[['SP500','HML','SMB','CMA']], force_background=True)
plot_portfolio_comparison(portfolio[['MultiSSD','SP500']], force_background=True)
# %%
