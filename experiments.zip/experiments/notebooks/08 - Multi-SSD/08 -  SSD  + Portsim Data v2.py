# %% [markdown]
# Uma solução para este problema é utilizar uma formulação em planos de corte, isto é, uma formulação que possui um número enorme de restrições. A formulação abaixo consegue modelar o problema acima de forma correta:
# 
# \begin{align}
#     \max \mathcal{V} \tag{1} \\
#     \mathcal{V} \leq \frac{1}{T} \sum_{j \in \mathcal{J}_t} \sum_{i=1}^{N} R_{ij} w_i - \hat{\tau}_t, \qquad \forall \mathcal{J}_t \subset \{1, \dots, T\}, \quad |\mathcal{J}_t| = t, t = \{1, \dots, T\}     \tag{2} \\
#     \sum_{i=1}^{N} w_i = 1                                                                                                                                    \tag{3} \\
#     \mathcal{V} \in \mathbb{R}                                                                                                                                \tag{4} \\
#     w_i \geq 0, \quad i = 1, \dots, N                                                                                                                         \tag{5} \\
# \end{align}
# 
# No entanto uma modificação sútil incluindo variáveis adicionais $V_s$ permitem mais flexibilidade para esse modelo e em mais avançados elas permitem outros usos (Modelo Unscaled - Unonditional Expectation).
# 
# \begin{align*}
# \max \quad & \mathcal{V} \\
# \text{sujeito a} \quad & \mathcal{V} \leq \mathcal{V}_s \quad && \forall s = \{1, \ldots, S\} \\
# & \mathcal{V}_s \leq \frac{1}{T} \sum_{j \in \mathcal{J}_s} \sum_{i=1}^{N} r_{ij} w_i - \hat{\tau}_s \quad && \forall \mathcal{J}_s \subset \{1, \ldots, S\}, |\mathcal{J}_s| = s,\ s = \{1, \ldots, S\} \\
# & \sum_{i=1}^{N} w_i = 1 \\
# & \mathcal{V} \in \mathbb{R}
# \end{align*}
# 
# Modelo Scaled - Conditional Expectation(CVaR):
# 
# \begin{align*}
# \max \quad & \mathcal{V} \\
# \text{sujeito a} \quad & \mathcal{V} \leq \mathcal{V}_s \quad && \forall s = \{1, \ldots, S\} \\
# & \mathcal{V}_s \leq \frac{t}{T} \sum_{j \in \mathcal{J}_s} \sum_{i=1}^{N} r_{ij} w_i - \hat{\tau}_s \quad && \forall \mathcal{J}_s \subset \{1, \ldots, S\}, |\mathcal{J}_s| = s,\ s = \{1, \ldots, S\} \\
# & \sum_{i=1}^{N} w_i = 1 \\
# & \mathcal{V} \in \mathbb{R}
# \end{align*}
# 
# %% [markdown]
# ### Notas sobre esse Experimento
# %% [markdown]
# Basic experiment:
# 
# - Scaled SSD model
# - 200 days in-sample
# - Data for S&P500 companies
# - Rebalancing every 21 days
# - Out-of-sample period from 01/01/2024 to 01/06/2024
# - No transaction costs, or lot sizes
# 
# Benchmarks: S&P500 index and HML, SMB and CMA factor returns.
# 
# - CMA: Conservative minus Aggressive
# - HML: High minus Low
# - SMB: Small minus Big
# 
# Notas Toni
# 
# - Insample tem 200 dias mais 1 e esse 1 é a primeira data do oos, nesse caso `date1`
# - oos inclui `date1` e `date2` a menos que seja feriado ou fds
# - Se `date1` for feriado/fds ele pega a primeira data após `date1`
# - Se `date2` for feriado/fds ele pega a primeira data antes `date2`
# - Arbex faz algum procedimento para exluir colunas e preencher dados
#     - Descobri isso olhando o numero de colunas do corte do dataset utilizado para o rebalanceamento da primeira semana
#     - Entram 644 colunas quando inspecionamos o objeto date criado a partir do json e permanecem 502 ao inspecionarmos o objeto `exp2.getRebalanceData("2024-02-01")`
# - Para as colunas que ficaram mas que ainda tem dados ausentes primeiros são calculados os retornos e depois é feito o `prices.fillna(0, inplace=True)` e
# 
# %% [markdown]
# ### Imports
# %%
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import matplotlib.dates as mdates
from matplotlib.ticker import MultipleLocator

import cplex
from docplex.mp.model import Model
from cplex.callbacks import UserCutCallback, LazyConstraintCallback, SolveCallback
from docplex.mp.callbacks.cb_mixin import ConstraintCallbackMixin

os.system('cls' if os.name == 'nt' else 'clear')

np.set_printoptions(precision=8, suppress=True)
pd.set_option('display.max_columns', 1000)
pd.set_option('expand_frame_repr', False)
# %% [markdown]
# ## Functions
# %%
def sort_benchmark(benchmark: pd.DataFrame) -> np.ndarray:
    """
    Ordena um benchmark (DataFrame com uma única coluna)
    em ordem crescente.

    Args:
        benchmark: DataFrame contendo exatamente uma coluna.

    Returns:
        np.ndarray contendo os valores ordenados.
    """

    if benchmark.shape[1] != 1:
        raise ValueError(
            "O DataFrame deve conter exatamente uma coluna."
        )

    col = benchmark.columns[0]

    return np.sort(benchmark[col].values)
# %%
def missing_percentage(df, threshold=0):
    """
    Retorna a quantidade e porcentagem de valores ausentes por coluna,
    filtrando colunas com porcentagem maior que o threshold.

    Se nenhuma coluna tiver valores ausentes, retorna uma mensagem.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame analisado.

    threshold : float
        Percentual mínimo de dados ausentes para exibir a coluna.
        Exemplo: threshold=10 mostra apenas colunas com mais de 10% de NaN.
    """

    missing_pct = df.isnull().mean() * 100

    result = pd.DataFrame({
        'missing_count': df.isnull().sum(),
        'missing_percentage': missing_pct
    })

    # mantém apenas colunas com pelo menos 1 NaN
    result = result[result['missing_count'] > 0]

    # verifica se existe alguma coluna com NaN
    if result.empty:
        return "Nenhuma coluna possui dados faltantes."

    # aplica threshold
    result = result[result['missing_percentage'] > threshold]

    return result.sort_values(by='missing_percentage', ascending=False)
# %%
def percentual_valores_ausentes(df):
    """
    Retorna a porcentagem de valores ausentes por coluna.
    """

    percentual = (df.isnull().sum() / len(df)) * 100

    resultado = (
        percentual
        .sort_values(ascending=False)
        .to_frame(name='percentual_ausente')
    )

    return resultado
# %% [markdown]
# ### Portsim Data
# %%
in_sample_days      = 200
oos_start           = '2024-01-01'
oos_end             = '2024-06-01'
# %%
data_prices = pd.read_csv('../../data/portsim_asset_prices_full.csv', index_col=0)
data_prices.index.min(), data_prices.index.max()
# %%
portsim_multissd_asset_prices  = pd.read_csv("../../data/portsim-multissd-asset-prices.csv")
portsim_multissd_asset_returns = pd.read_csv("../../data/portsim-multissd-asset-returns.csv")

print(portsim_multissd_asset_prices.shape)
print(portsim_multissd_asset_returns.shape)

# %%
portsim_multissd_asset_prices.index  = data_prices.index
portsim_multissd_asset_returns.index = data_prices.index
# %%
portsim_multissd_asset_returns = portsim_multissd_asset_returns.iloc[1:]
portsim_multissd_asset_returns
# %%
missing_percentage(portsim_multissd_asset_prices), missing_percentage(portsim_multissd_asset_returns)

# %%
portsim_oos_prices = portsim_multissd_asset_prices.loc[oos_start:oos_end]
# %%
missing_percentage(portsim_oos_prices)
# %% [markdown]
# ### Benchmark
# %%
benchmarks_data = pd.read_csv('../../data/multissd-benchmarks-data.csv', parse_dates=['date'])
benchmarks_data.set_index('date', inplace=True)
sp500_benchmark_data = pd.read_csv("../../data/sp500_benchmark_data.csv")
sp500_benchmark_data.index = benchmarks_data.index

sp500_benchmark_data = sp500_benchmark_data.iloc[1:]
sp500_benchmark_data.head()
# %%
# bench = sp500_benchmark_data['SP500']
# bench[:200]
# sorted(bench)
# %%
benchmark_returns = sp500_benchmark_data[['SP500']]
benchmark_returns.head()
# %%
n_cols = 600

portsim_multissd_asset_returns = portsim_multissd_asset_returns.iloc[:, :n_cols]
portsim_oos_prices             = portsim_oos_prices.iloc[:, :n_cols]
# %%
portsim_multissd_asset_returns.shape, sp500_benchmark_data.shape, portsim_oos_prices.shape
# %%
portsim_multissd_asset_returns.index.min(), portsim_multissd_asset_returns.index.max(), portsim_oos_prices.index.min(), portsim_oos_prices.index.max()
# %%
missing_percentage(portsim_multissd_asset_returns), missing_percentage(portsim_oos_prices)
# %%
portsim_multissd_asset_returns.head()
# %%
len(sp500_benchmark_data)
# %%
class SSDLazyCallback(ConstraintCallbackMixin, LazyConstraintCallback, SolveCallback):

    def __init__(self, env):
        LazyConstraintCallback.__init__(self, env)
        ConstraintCallbackMixin.__init__(self)
        self.n_calls   = 0
        self.tolerance = 1e-6
        self.debug = True
        self.cuts_debug = True

    def __call__(self):

        if self.get_cplex_status() == self.status.optimal:
            self.n_calls += 1

            if self.cuts_debug: print('-' * 40)
            if self.cuts_debug: print(f"\n [INFO]: Running separation algorithm #{self.n_calls} ")

            n_scenarios   = len(self.scenarios)
            n_assets      = self.scenarios.shape[1]
            curr_solution = self.make_complete_solution()
            curr_w_values = {var.name: self.get_values(var.index) for var in self.w_vars}
            V_value       = curr_solution[self.model.get_var_by_name('V')]
            w_values      = [self.get_values(w.index) for w in self.w_vars]

            if self.cuts_debug:
                print(f"\n{'V':<5}: {V_value:.5f}")
                print(f"Weights:")
                my_array = np.array([w for w in w_values])
                print(f"\n{my_array}")
                # formatted_values = [f"{w:.5f}" for w in w_values]
                # print(f"\t{'Weights':<22}: {formatted_values}")

            # Calculando Tail(R'w) para todo t.
            portfolio_returns = self.scenarios @ w_values

            # Ordenar pelo valor do retorno e Imprimir formatado
            idx_returns = list(enumerate(portfolio_returns))
            sorted_idx_returns  = sorted(idx_returns, key=lambda x: x[1])
            if self.debug:
                for rank, (original_index, value) in enumerate(sorted_idx_returns, start=1):
                    print(f"\t{rank:2}-th worst return: {value: .5f} (index {original_index})")
                print()

            # Ordena os retornos do portfólio e do benchmark
            sorted_p_returns = sorted(portfolio_returns)
            sorted_b_returns = self.benchmark

            # Soma acumulada do Benchmark
            cum_p_returns = np.cumsum(sorted_p_returns)
            cum_b_returns = np.cumsum(sorted_b_returns)


            print("ON CALLBACK")
            print(f"\nCum. Bench. Returns")
            print(np.array(cum_b_returns))
            print(f"\nCum. Port. Returns")
            print(np.array(cum_p_returns))

            max_diff  = -np.inf
            max_index = None
            max_ret   = None

            #   Sum(Tail(R_1'w)) - tau_1
            #   Sum(Tail(R_1'w) + Tail(R_2'w)) - tau_2
            #   Sum(Tail(R_1'w) + Tail(R_2'w) + Tail(R_3'w)) - tau_3
            for s, ret in enumerate(cum_p_returns):

                tau_s    = cum_b_returns[s]
                rhs_expr = ret - tau_s

                diff = V_value - rhs_expr
                if self.debug: print(f"\t|Js| = {s + 1:2d}, C: {V_value:.5f} - ({ret:.5f}) <= ({tau_s:.5f}) (Violated by {diff:.5f})")

                if V_value > rhs_expr + self.tolerance:

                    if diff > max_diff:
                        max_diff  = diff
                        max_index = s
                        max_ret   = ret

            if max_index is not None:

                if self.cuts_debug:
                    print(f"\n[INFO]: SSD constraint violated to Vs_{max_index}\n")
                    print(f"[INFO]: Violation: {max_diff}\n")

                Vs = self.model.get_var_by_name(f"Vs_{max_index}")

                # Obtém os índices dos |J| piores cenários
                worst_scenario_indices = [idx for idx, _ in sorted_idx_returns[:max_index + 1]]  # max_index é zero-based
                if self.debug: print(f"\tWorst Scenario Indices: {worst_scenario_indices}")

                # Soma os retornos desses cenários
                cumulative_scenario = np.sum(self.scenarios[worst_scenario_indices, :], axis=0)

                # Construção explícita do corte
                scenario_return = self.model.sum(cumulative_scenario[i] * self.w_vars[i] for i in range(n_assets))
                rhs             = cum_b_returns[max_index]

                formatted_values = [f"{ret:.5f}" for ret in cumulative_scenario]
                if self.debug: print(f"\tWorst Scenario Returns: {formatted_values}")

                if self.cuts_debug:
                    print(f"\t{'Cut to be added':<22}: ", end="")
                    for i in range(n_assets):
                        print(f"{cumulative_scenario[i]:.5f} {self.w_vars[i].name} + ", end="")
                    print(f"1 {Vs} <= {rhs:.5f}\n")

                # Adiciona restrição
                cpx_lhs, sense, cpx_rhs = self.linear_ct_to_cplex(Vs <= scenario_return - rhs)

                self.add(cpx_lhs, sense, cpx_rhs)

                if self.cuts_debug:
                    print(f"\t\033[92m> Violated constraint added.\033[0m\n")
                    print(f"\t> End of Separation Algorithm.")
                    print('-' * 40)
# %% [markdown]
# ### Model
# %%
def solve_ssd(scenarios, benchmark, callback=False, verbose=False,):

    print("\n=== STARTING SSD MODEL ===")
    model = Model(name='SSD')
    n_scenar = scenarios.shape[0]
    n_assets = scenarios.shape[1]

    scenarios = np.array(scenarios)
    benchmark = np.array(benchmark)


    # Variáveis
    model.parameters.preprocessing.presolve = 0
    model.parameters.mip.display = 4
    model.parameters.threads = 1
    model.parameters.emphasis.numerical = 1
    model.parameters.randomseed = 0
    model.parameters.emphasis.mip = 2
    model.parameters.simplex.tolerances.optimality = 1e-9
    model.parameters.simplex.tolerances.feasibility = 1e-9
    model.parameters.timelimit = 120
    model.parameters.mip.tolerances.absmipgap = 0
    model.parameters.mip.tolerances.mipgap = 0
    model.parameters.mip.tolerances.integrality = 0

    # Variáveis
    w  = model.continuous_var_list(n_assets, lb=0, ub=1, name='wl')
    Vs = model.continuous_var_list(n_scenar, name='Vs', lb=-model.infinity, ub=model.infinity)
    V  = model.continuous_var(name="V", lb=-model.infinity, ub=model.infinity)
    cb = model.binary_var(name='cb_temp')


    # Restrições básicas
    model.add_constraint(model.sum(w) == 1, ctname="budget")

    for t in range(n_scenar):
        model.add_constraint(V <= Vs[t] , ctname=f"maxmin_{t}")

    for t in range(n_scenar):
        scenario_return = model.sum(((scenarios[t, i] * w[i])) for i in range(n_assets))
        model.add_constraint(Vs[t] <= scenario_return - benchmark[0], ctname=f"ssd_{t}")

    model.maximize(V + cb)

    if True:
        for ct in model.iter_constraints():
            print(f"Name: {ct.name}, Expression: {ct.left_expr} {ct.sense} {ct.right_expr}")


    model.export_as_lp("../../models/toni-multssd-model.lp")

    if verbose:
        print(model.print_information())

    if callback:
        # Registra o callback e passa os parâmetros necessários
        lazy_cb = model.register_callback(SSDLazyCallback)
        lazy_cb.scenarios = scenarios
        lazy_cb.benchmark = benchmark
        lazy_cb.w_vars    = w
        lazy_cb.verbose   = verbose

    model.lazy_callback = lazy_cb

    print("\nIniciando processo de otimização...")
    sol = model.solve(log_output=False)

    if sol:
        optimized_weights = [sol[wi] for wi in w]
        weights           = np.array(optimized_weights)
        print("\n[INFO]: Solução encontrada:")
        print(f"\tV              {sol[V]}")
        print(f"\tBest Solution = {sol.get_objective_value()}")
        print(f"\tNº of Cuts    = {model.get_cuts()['user']}")
        print()
        # for i, val in enumerate(optimized_weights):
        #     print(f"\tw[{i}] = {val}")


        return sol.get_objective_value(), weights
    else:
        raise RuntimeError("No solution found for the optimization problem!")
# %% [markdown]
# ### Validation
# %%
def WFV(prices, returns, benchmark, model_output=True, sliding=True):

    INITIAL_CAPITAL       = 1000000

    portfolio_shares_held = pd.DataFrame()
    weights_invested      = pd.DataFrame()
    rebalances_df         = pd.DataFrame()
    valuation_df          = pd.DataFrame()
    shares_df             = pd.DataFrame()
    norm_portfolio_df     = pd.DataFrame(columns=["SSD"])  # ← ADIÇÃO

    print('---------------------------------------------------------------')
    print('[INFO]: Simulation Started...\n')

    initial_train_days = 200
    validation_days    = 1
    rebalance_freq     = 21

    data_length = len(returns)
    # max_steps   = data_length - initial_train_days + 1
    max_steps = len(prices)

    last_share = None

    print(returns.shape)
    print(returns.index.min())
    print(returns.index.max())


    for step in range(0, max_steps, validation_days):

        train_start = step if sliding else 0
        train_end   = train_start + initial_train_days

        train           = returns.iloc[train_start:train_end]
        train_bench     = benchmark.iloc[train_start:train_end]
        valid           = returns.iloc[train_end-1:train_end]

        train_bench_sorted     = sort_benchmark(train_bench)

        np.set_printoptions(precision=8, suppress=True)

        print(f"\nRef:")
        print(np.array(train_bench).flatten())

        for i, col in enumerate(train.columns):
            print(f"\nAsset: {i} - {col}")
            # Converte os valores da coluna para um array numpy
            valores_array = train[col].to_numpy()
            print(f"\n{valores_array}")

        print("------------- END INSTANCE - --------------")

        print("All references:")
        print(f"\nRef:")
        print(np.array(train_bench).flatten())

        print(f"\nSorted Ref:")
        print(np.array(train_bench_sorted))

        func_obj, weights_arr = solve_ssd(train, train_bench_sorted, callback=True, verbose=False)

        print(np.array(weights_arr))

        break

        weights_opt = pd.DataFrame([weights_arr], columns=valid.columns, index=valid.index)

        print(f"Day: {step + 1} ({valid.index.min()})")
        print(f"\tSum proportions: {np.sum(weights_arr)*100}%")
        print(f"\tFUNÇÃO OBJETIVO: {func_obj}")

        # ============================================================
        # SIMULATION
        # ============================================================

        price = np.array(prices.loc[prices.index[step], :])

        # ============================================================
        # DIA 0 — primeiro dia da simulação
        # ============================================================
        if step == 0:
            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            valuation     = (weights_arr * INITIAL_CAPITAL)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

            train.to_csv(f"rebalanceWeights-{valid.index.min()}.csv", index=False)

        # ============================================================
        # DIA DE REBALANCEAMENTO
        # ============================================================
        elif step % rebalance_freq == 0:

            print(f"\n\t\033[92mToday is a rebalancing day.\033[0m")

            train.to_csv(f"rebalanceWeights-{valid.index.min()}.csv", index=False)

            valuation_normal = (last_share * price)
            total_value      = np.sum(valuation_normal)

            print(f"\tValuation before rebalance: {total_value}")

            valuation     = (weights_arr * total_value)
            share         = (valuation / price)
            rebalances_df = pd.concat([rebalances_df, weights_opt])

        # ============================================================
        # DIA SEM REBALANCEAMENTO
        # ============================================================
        else:
            share     = last_share
            valuation = share * price

        # ============================================================
        # Armazenamento
        # ============================================================
        date_idx = valid.index[0]

        valuation_df     = pd.concat([valuation_df,pd.DataFrame([valuation], index=[date_idx], columns=valid.columns)])
        shares_df        = pd.concat([shares_df, pd.DataFrame([share], index=[date_idx], columns=valid.columns)])
        weights_invested = pd.concat([weights_invested, weights_opt])

        norm_portfolio_df.loc[date_idx, "SSD"] = (np.sum(valuation) / INITIAL_CAPITAL)

        last_share = share

        print(f"\tPortfolio Value: {np.sum(valuation)}")
        print(f"\tNorm Portfolio: {np.sum(valuation)/INITIAL_CAPITAL}")
        print('---------------------------------------------------------------\n')


    return (norm_portfolio_df, weights_invested, rebalances_df, valuation_df, shares_df)

# %% [markdown]
# ### Running Strategy
# %%
# %%time

if __name__ == "__main__":
    

    portfolio, weightsInvested, weightsRebalance, portfolioValuation, portfolioShares = WFV(portsim_oos_prices,
                                                                                            portsim_multissd_asset_returns,
                                                                                            benchmark_returns,
                                                                                            model_output=True, 
                                                                                            sliding=True)

    print('==========================================================')
    print('Finalising simulation...')
# %%
print(portfolio.shape)
portfolio.head(200)
# %%
print(weightsRebalance.shape)
weightsRebalance.head(40)
# %%
print(portfolioValuation.shape)
portfolioValuation.head()
# %%
print(weightsInvested.shape)
weightsInvested.head()
# %%
print(portfolioShares.shape)
portfolioShares.head()
# %%
df_subset = portfolioShares.iloc[:2]

df_limpo = df_subset.loc[:, (df_subset != 0).any(axis=0)]
print(df_limpo.shape)
# %%
df_limpo
# %%
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd

def plot_portfolio_comparison(portfolio, force_background=False):
    """
    Plota o comparativo de performance entre o portfólio (estratégia)
    e o benchmark S&P 500, ambos normalizados.
    """
    plt.figure(figsize=(20, 10))

    ax = plt.gca()

    if force_background:
        ax.set_facecolor("white")
        ax.figure.set_facecolor("white")

    # CORREÇÃO AQUI: Convertendo o índice para Datetime para a linha não sumir/cortar
    index_dt = pd.to_datetime(portfolio.index)

    # Plotagem usando o índice convertido em Datetime nativo
    plt.plot(index_dt, portfolio["SSD"], label="SSD Toni")
    plt.plot(index_dt, portfolio["SP500"], label="SP500")

    if "Risk free rate" in portfolio.columns:
        plt.plot(index_dt, portfolio["Risk free rate"], label="Risk free rate", linestyle="--")

    # ============================================================
    # CONFIGURAÇÃO DO EIXO X (Dias 01 e 15 sem quebrar as linhas)
    # ============================================================
    # Localiza matematicamente os dias 1 e 15 de cada mês ao longo da linha do tempo
    ax.xaxis.set_major_locator(mdates.MonthLocator(bymonthday=[1, 15]))

    # Formata a exibição exatamente como você quer: Ano-Mês-Dia
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    # ============================================================

    plt.title("Comparativo de Performance dos Portfólios", fontsize=20)
    plt.xlabel("Data", fontsize=16)
    plt.ylabel("Valor normalizado", fontsize=16)

    plt.legend(fontsize=14)
    plt.grid(True, alpha=0.3)   # O grid segue os dias 1 e 15 automaticamente
    plt.xticks(rotation=45)

    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.tick_params(axis='both', colors='gray', labelsize=14)

    plt.tight_layout()
    plt.show()
# %%
sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
sp500_prices.set_index('date', inplace=True)
sp500_slice = sp500_prices.loc['2023-10-31':'2023-11-30', 'SP500'].abs()
sp500_slice
# %%
sp500_prices = pd.read_csv('../../data/extracted_SP500_data.csv', parse_dates=['date'])
sp500_prices.set_index('date', inplace=True)
sp500_slice = sp500_prices.loc[oos_start:oos_end, 'SP500'].abs()
sp500 = sp500_slice / sp500_slice.iloc[0]
portfolio['SP500'] = sp500
portfolio['Risk free rate'] = 1.0
portfolio
# %%
plot_portfolio_comparison(portfolio, force_background=True)
# %%

# %%
