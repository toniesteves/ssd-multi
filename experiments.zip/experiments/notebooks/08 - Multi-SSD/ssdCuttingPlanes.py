
import numpy as np
import pandas as pd

import cplex
from docplex.mp.model import Model
from cplex.callbacks import UserCutCallback, LazyConstraintCallback, SolveCallback
from docplex.mp.callbacks.cb_mixin import ConstraintCallbackMixin

pd.set_option('display.max_columns', 1000)
pd.set_option('expand_frame_repr', False)


returns = pd.read_csv('../../data/scenario-returns.csv')

benchmark = sorted(returns.iloc[:, -1])

scenarios = np.array(returns.iloc[:,:10])


n_scenar = scenarios.shape[0]
n_assets = scenarios.shape[1]

n_scenar, n_assets


class SSDLazyCallback(ConstraintCallbackMixin, LazyConstraintCallback, SolveCallback):
    
    def __init__(self, env):
        LazyConstraintCallback.__init__(self, env)
        ConstraintCallbackMixin.__init__(self)
        self.n_calls   = 0
        self.tolerance = 1e-6
        
    def __call__(self):

        if self.get_cplex_status() == self.status.optimal:
            self.n_calls += 1

            print('-' * 40)
            print(f"\n [INFO]: Running separation algorithm #{self.n_calls} ")
            n_scenarios   = len(self.scenarios)
            curr_solution = self.make_complete_solution()                                                         
            curr_w_values = {var.name: self.get_values(var.index) for var in self.w_vars}
            V_value       = curr_solution[self.model.get_var_by_name('V')]                                     
            w_values      = [self.get_values(w.index) for w in self.w_vars]
            
            print(f"\n\tValue of V: {V_value:.5f}")
            formatted_values = [f"{w:.5f}" for w in w_values]
            print(f"\tWeights:   {formatted_values}\n")

            # Calculando Tail(R'w) para todo t.
            portfolio_returns = self.scenarios @ w_values 
            
            # Ordenar pelo valor do retorno e Imprimir formatado
            idx_returns = list(enumerate(portfolio_returns))
            sorted_idx_returns  = sorted(idx_returns, key=lambda x: x[1])
            for rank, (original_index, value) in enumerate(sorted_idx_returns, start=1):
                print(f"\t{rank:2}-th worst return: {value: .5f} (index {original_index})")
            print()
            
            # Ordena os retornos do portfólio e do benchmark
            sorted_p_returns = sorted(portfolio_returns)
            sorted_b_returns = self.benchmark
            
            # Soma acumulada do Benchmark
            cum_p_returns = np.cumsum(sorted_p_returns)
            cum_b_returns = np.cumsum(sorted_b_returns)

            max_diff  = -np.inf
            max_index = None
            max_ret   = None
            
            #   Sum(Tail(R_1'w)) - tau_1
            #   Sum(Tail(R_1'w) + Tail(R_2'w)) - tau_2
            #   Sum(Tail(R_1'w) + Tail(R_2'w) + Tail(R_3'w)) - tau_3      
            for s, ret in enumerate(cum_p_returns):

                tau_s    = cum_b_returns[s]
                rhs_expr = ret - tau_s

                diff = V_value - rhs_expr
                print(f"\t|Js| = {s + 1:2d}, C: {V_value:.5f} - ({ret:.5f}) <= ({tau_s:.5f}) (Violated by {diff:.5f})")
                
                if V_value > rhs_expr + self.tolerance:
                    
                    if diff > max_diff:
                        max_diff  = diff
                        max_index = s
                        max_ret   = ret

            if max_index is not None: 

                print(f"\n[INFO]: SSD constraint violated to Vs_{max_index}\n")
                print(f"[INFO]: Violation: {max_diff}\n")
                
                Vs = self.model.get_var_by_name(f"Vs_{max_index}")

                # Obtém os índices dos |J| piores cenários
                worst_scenario_indices = [idx for idx, _ in sorted_idx_returns[:max_index + 1]]  # max_index é zero-based
                print(f"\tWorst Scenario Indices: {worst_scenario_indices}")
                
                # Soma os retornos desses cenários
                cumulative_scenario = np.sum(self.scenarios[worst_scenario_indices, :], axis=0)
                
                # Construção explícita do corte
                scenario_return = self.model.sum(cumulative_scenario[i] * self.w_vars[i] for i in range(n_assets))
                rhs             = cum_b_returns[max_index]

                formatted_values = [f"{ret:.5f}" for ret in cumulative_scenario]
                print(f"\tWorst Scenario Returns: {formatted_values}")

                print("\n\tCut to be added: ", end="")
                for i in range(n_assets):
                    print(f"{cumulative_scenario[i]:.5f} {self.w_vars[i].name} + ", end="")
                print(f"1 {Vs.name} <= {rhs:.5f}\n")

                # Adiciona restrição
                cpx_lhs, sense, cpx_rhs = self.linear_ct_to_cplex(Vs <= scenario_return - rhs)

                self.add(cpx_lhs, sense, cpx_rhs)

                print(f"[INFO]: Violated constraint added.\n")
                print(f"[INFO]: End of Separation Algorithm. ")
                print('-' * 40 + '\n\n')


def solve_ssd(scenarios, benchmark, callback=False, verbose=False,):

    print("\n=== STARTING SSD MODEL ===")
    model = Model(name='SSD')

    # Variáveis
    model.parameters.preprocessing.presolve = 0
    model.parameters.mip.display = 4
    model.parameters.threads = 1
    model.parameters.emphasis.numerical = 1
    model.parameters.randomseed = 0
    model.parameters.emphasis.mip = 2
    model.parameters.simplex.tolerances.optimality = 1e-9
    model.parameters.simplex.tolerances.feasibility = 1e-9
    model.parameters.timelimit = 120
    model.parameters.mip.tolerances.absmipgap = 0
    model.parameters.mip.tolerances.mipgap = 0
    model.parameters.mip.tolerances.integrality = 0

    # Variáveis
    w  = model.continuous_var_list(n_assets, lb=0, ub=1, name='wl')
    Vs = model.continuous_var_list(n_scenar, name='Vs', lb=-model.infinity, ub=model.infinity)
    V  = model.continuous_var(name="V", lb=-model.infinity, ub=model.infinity) 
    cb = model.binary_var(name='cb_temp')  
    
    # Restrições básicas
    model.add_constraint(model.sum(w) == 1, ctname="budget")
    
    for t in range(n_scenar):
        model.add_constraint(V <= Vs[t] , ctname=f"maxmin_{t}")

    for t in range(n_scenar):
        scenario_return = model.sum(((scenarios[t, i] * w[i])) for i in range(n_assets))
        model.add_constraint(Vs[t] <= scenario_return - benchmark[0], ctname=f"ssd_{t}")

    model.maximize(V + cb)

    if verbose:
        for ct in model.iter_constraints():
            print(f"Name: {ct.name}, Expression: {ct.left_expr} {ct.sense} {ct.right_expr}")
            
    model.export_as_lp("../../models/toni-ssd-model.lp")

    if verbose:
        print(model.print_information())
    
    if callback:
        # Registra o callback e passa os parâmetros necessários
        lazy_cb = model.register_callback(SSDLazyCallback)
        lazy_cb.scenarios = scenarios
        lazy_cb.benchmark = benchmark
        lazy_cb.w_vars    = w  
        lazy_cb.verbose   = verbose
    
    model.lazy_callback = lazy_cb
    
    print("\nIniciando processo de otimização...")
    sol = model.solve(log_output=True)
    
    if sol:
        w_solutions = [sol[wi] for wi in w]
        # print(f"Cortes: {model.get_cuts()}")
        print("\n[INFO]: Solução encontrada:")
        print(f"\tV              {sol[V]}")
        print(f"\tBest Solution = {sol.get_objective_value()}")
        print(f"\tNº of Cuts    = {model.get_cuts()['user']}")
        print()
        for i, val in enumerate(w_solutions):
            print(f"\tw[{i}] = {val}")
    else:
        print("No solutions found!")


if __name__ == "__main__":
    solve_ssd(scenarios, benchmark, callback=True, verbose=False)





